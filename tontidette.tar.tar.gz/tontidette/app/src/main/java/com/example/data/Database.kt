package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Debt::class, Tontine::class, UserProfile::class],
    version = 7,
    exportSchema = false
)
abstract class TontiDetteDatabase : RoomDatabase() {
    abstract fun debtDao(): DebtDao
    abstract fun tontineDao(): TontineDao
    abstract fun userProfileDao(): UserProfileDao

    companion object {
        @Volatile
        private var INSTANCE: TontiDetteDatabase? = null

        fun getDatabase(context: Context): TontiDetteDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TontiDetteDatabase::class.java,
                    "tontidette_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
