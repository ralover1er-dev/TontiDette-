package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.rememberAsyncImagePainter
import com.example.data.Tontine
import com.example.data.TontineMember
import com.example.ui.utils.CurrencyUtils
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

// Helper to calculate turn dates
@android.annotation.SuppressLint("NewApi")
fun getTurnDateString(startDateStr: String, frequency: String, turn: Int): String {
    return try {
        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val date = LocalDate.parse(startDateStr, formatter)
        val turnDate = if (frequency.lowercase().contains("hebdo")) {
            date.plusWeeks((turn - 1).toLong())
        } else {
            date.plusMonths((turn - 1).toLong())
        }
        val outFormatter = DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale.FRENCH)
        turnDate.format(outFormatter)
    } catch (e: Exception) {
        "Tour $turn"
    }
}

// WhatsApp Intent Trigger
fun sendWhatsAppMessage(context: android.content.Context, phoneNumber: String, message: String) {
    try {
        val cleanPhone = phoneNumber.replace(" ", "").replace("+", "")
        val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=${android.net.Uri.encode(message)}"
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            data = android.net.Uri.parse(url)
            `package` = "com.whatsapp"
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            val cleanPhone = phoneNumber.replace(" ", "").replace("+", "")
            val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=${android.net.Uri.encode(message)}"
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            context.startActivity(intent)
        } catch (e2: Exception) {
            // Error launching browser
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TontinesScreen(
    tontines: List<Tontine>,
    onAddTontine: (String, Double, Int, Int, String) -> Unit, // Legacy
    onIncrementTurn: (Tontine, String?) -> Unit,
    onDecrementTurn: (Tontine) -> Unit,
    onDeleteTontine: (Tontine) -> Unit,
    onVoteForTreasurer: (Tontine, String) -> Unit, // Legacy
    onUploadProof: (Tontine, String) -> Unit, // Legacy
    onValidateProof: (Tontine, Boolean) -> Unit, // Legacy
    onResetProof: (Tontine) -> Unit, // Legacy
    
    // NEW POWERFUL PARAMS
    onAddTontineWithDate: (String, Double, Int, String, String) -> Unit = { _, _, _, _, _ -> },
    onAddTontineWithDateAndVisibility: (String, Double, Int, String, String, String, String) -> Unit = { _, _, _, _, _, _, _ -> },
    onAddMember: (Tontine, String, String, String) -> Unit = { _, _, _, _ -> },
    onRemoveMember: (Tontine, TontineMember) -> Unit = { _, _ -> },
    onVoteForMember: (Tontine, String) -> Unit = { _, _ -> },
    onUploadMemberProof: (Tontine, String, String) -> Unit = { _, _, _ -> },
    onUploadBeneficiaryProof: (Tontine, String, String) -> Unit = { _, _, _ -> },
    onConfirmMemberPayment: (Tontine, String) -> Unit = { _, _ -> },
    onRejectMemberPayment: (Tontine, String) -> Unit = { _, _ -> },
    onSetBeneficiary: (Tontine, String) -> Unit = { _, _ -> },
    
    // JOIN REQUEST PARAMS
    onJoinRequest: (Tontine) -> Unit = {},
    onHandleJoinRequest: (Tontine, String, String, Boolean, String) -> Unit = { _, _, _, _, _ -> },
    
    currentUserName: String = "Lesly Zoyem",
    currentUserPhone: String = "",
    currentUserRole: String = "Créateur",
    currentUserCity: String = "Douala",
    
    initShowCreate: Boolean = false,
    onDismissCreate: () -> Unit = {},
    
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    LaunchedEffect(initShowCreate) {
        if (initShowCreate) {
            showCreateDialog = true
        }
    }
    var activeSubTab by remember { mutableStateOf(0) } // 0: Mes Tontines, 1: Découvrir
    var selectedDiscoverCity by remember { mutableStateOf(currentUserCity) }
    var cityDropdownExpanded by remember { mutableStateOf(false) }

    val cleanUserPhone = currentUserPhone.replace(" ", "").replace("+", "")

    // Filter tontines where user is a member or creator for "Mes Tontines"
    val mesTontines = tontines.filter { tontine ->
        (cleanUserPhone.isNotBlank() && tontine.userId == cleanUserPhone) ||
        tontine.getMembersList().any { member ->
            (currentUserName.isNotBlank() && member.name.equals(currentUserName, ignoreCase = true)) ||
            (cleanUserPhone.isNotBlank() && member.phone.replace(" ", "").replace("+", "") == cleanUserPhone)
        }
    }

    // Filter public tontines for selected city in "Découvrir"
    val discoverTontines = tontines.filter { tontine ->
        (tontine.visibility == "Publique" || tontine.visibility == "Public") &&
        tontine.ville.lowercase() == selectedDiscoverCity.lowercase()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(16.dp))

            // TabBar Row
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = Color.Transparent,
                contentColor = Color(0xFF007A5E),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                        color = Color(0xFF007A5E)
                    )
                }
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = { Text("Mes Tontines", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 },
                    text = { Text("Découvrir", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (activeSubTab == 0) {
                // "Mes Tontines" Sub-tab
                if (mesTontines.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Groups,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.size(80.dp)
                            )
                            Text(
                                text = "Vous n'avez aucune tontine",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Créez une nouvelle tontine ou rejoignez-en une publique de votre choix.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp),
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Button(
                                onClick = { showCreateDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Créer une Tontine", fontWeight = FontWeight.Bold)
                            }
                            
                            OutlinedButton(
                                onClick = { activeSubTab = 1 },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Rejoindre une tontine", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        items(mesTontines, key = { it.id }) { tontine ->
                            TontineCardItem(
                                tontine = tontine,
                                onIncrementTurn = onIncrementTurn,
                                onDecrementTurn = onDecrementTurn,
                                onDeleteTontine = onDeleteTontine,
                                onAddMember = onAddMember,
                                onRemoveMember = onRemoveMember,
                                onVoteForMember = onVoteForMember,
                                onUploadMemberProof = onUploadMemberProof,
                                onUploadBeneficiaryProof = onUploadBeneficiaryProof,
                                onConfirmMemberPayment = onConfirmMemberPayment,
                                onRejectMemberPayment = onRejectMemberPayment,
                                onSetBeneficiary = onSetBeneficiary,
                                onHandleJoinRequest = onHandleJoinRequest,
                                currentUserName = currentUserName
                            )
                        }
                    }
                }
            } else {
                // "Découvrir" Sub-tab
                Column(modifier = Modifier.fillMaxSize()) {
                    // City selector row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF007A5E))
                            Text("Découvrir à :", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        }
                        Box {
                            OutlinedButton(
                                onClick = { cityDropdownExpanded = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text(selectedDiscoverCity, style = MaterialTheme.typography.bodySmall)
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                            DropdownMenu(expanded = cityDropdownExpanded, onDismissRequest = { cityDropdownExpanded = false }) {
                                listOf("Douala", "Yaoundé", "Bafoussam", "Garoua", "Bamenda", "Kribi").forEach { city ->
                                    DropdownMenuItem(text = { Text(city) }, onClick = {
                                        selectedDiscoverCity = city
                                        cityDropdownExpanded = false
                                    })
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (discoverTontines.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.SearchOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                                Text("Aucune tontine publique trouvée à $selectedDiscoverCity", style = MaterialTheme.typography.bodyMedium, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(bottom = 88.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(discoverTontines, key = { it.id }) { tontine ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(16.dp),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(tontine.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            // Show Delete icon ONLY if currentUserRole is Trésorier
                                            if (currentUserRole == "Trésorier") {
                                                IconButton(onClick = { onDeleteTontine(tontine) }) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = Color(0xFFCE1126))
                                                }
                                            }
                                        }
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            SuggestionChip(
                                                onClick = {},
                                                label = { Text(CurrencyUtils.formatFCFA(tontine.amountPerMember) + " / " + tontine.frequency) }
                                            )
                                            Text("${tontine.getMembersList().size} / ${tontine.membersCount} membres", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        // Determine Button State
                                        val isMember = tontine.getMembersList().any { it.name == currentUserName }
                                        val joinReq = tontine.getJoinRequestsList().firstOrNull { it.name == currentUserName }

                                        if (isMember) {
                                            Button(
                                                onClick = {},
                                                enabled = false,
                                                colors = ButtonDefaults.buttonColors(disabledContainerColor = Color.LightGray, disabledContentColor = Color.DarkGray),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Déjà membre")
                                            }
                                        } else if (joinReq != null) {
                                            val (btnText, btnColor) = when (joinReq.status) {
                                                "En attente" -> "Demande envoyée" to Color.Gray
                                                "Refusé" -> "Demande refusée" to Color(0xFFCE1126)
                                                else -> "Demande acceptée" to Color(0xFF007A5E)
                                            }
                                            Button(
                                                onClick = {},
                                                enabled = false,
                                                colors = ButtonDefaults.buttonColors(disabledContainerColor = btnColor.copy(alpha = 0.6f), disabledContentColor = Color.White),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text(btnText)
                                            }
                                        } else {
                                            Button(
                                                onClick = { onJoinRequest(tontine) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Demander à rejoindre", fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (activeSubTab == 0) {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = Color(0xFF004D40), // vert foncé
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 16.dp, end = 16.dp)
                    .testTag("create_tontine_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        }
    }

    if (showCreateDialog) {
        CreateTontineDialog(
            onDismiss = { 
                showCreateDialog = false
                onDismissCreate()
            },
            onConfirm = { name, amount, members, frequency, startDate, visibility, ville ->
                onAddTontineWithDateAndVisibility(name, amount, members, frequency, startDate, visibility, ville)
                showCreateDialog = false
                onDismissCreate()
            }
        )
    }
}

@Composable
fun TontineCardItem(
    tontine: Tontine,
    onIncrementTurn: (Tontine, String?) -> Unit,
    onDecrementTurn: (Tontine) -> Unit,
    onDeleteTontine: (Tontine) -> Unit,
    onAddMember: (Tontine, String, String, String) -> Unit,
    onRemoveMember: (Tontine, TontineMember) -> Unit,
    onVoteForMember: (Tontine, String) -> Unit,
    onUploadMemberProof: (Tontine, String, String) -> Unit,
    onUploadBeneficiaryProof: (Tontine, String, String) -> Unit,
    onConfirmMemberPayment: (Tontine, String) -> Unit,
    onRejectMemberPayment: (Tontine, String) -> Unit,
    onSetBeneficiary: (Tontine, String) -> Unit,
    onHandleJoinRequest: (Tontine, String, String, Boolean, String) -> Unit = { _, _, _, _, _ -> },
    currentUserName: String
) {
    val context = LocalContext.current
    val members = tontine.getMembersList()
    val totalPot = tontine.amountPerMember * tontine.membersCount
    val turnDate = getTurnDateString(tontine.startDate, tontine.frequency, tontine.currentTurn)

    // Determine current user member record
    val currentUserMember = members.firstOrNull { it.name == currentUserName }
    
    // Determine Treasurer (max votes, fallback to Creator or designated role)
    val maxVotesMember = members.filter { it.votes > 0 }.maxByOrNull { it.votes }
    val electedTreasurerName = when {
        maxVotesMember != null -> maxVotesMember.name
        else -> members.firstOrNull { it.role == "Trésorier" }?.name ?: members.firstOrNull { it.role == "Créateur" }?.name ?: "Aucun"
    }
    
    val isUserCreator = currentUserMember?.role == "Créateur" || members.firstOrNull()?.name == currentUserName
    val isUserTreasurer = currentUserMember?.role == "Trésorier" || currentUserName == electedTreasurerName
    
    val currentBeneficiaryMember = members.firstOrNull { it.name == tontine.nextBeneficiary }
    val isBeneficiaryProofUploaded = currentBeneficiaryMember?.beneficiaryProofUri != null

    var showMembersDialog by remember { mutableStateOf(false) }
    var showSelectBeneficiaryDialog by remember { mutableStateOf(false) }
    var selectedBeneficiaryName by remember { mutableStateOf("") }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    // Visual Media Screenshot Pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                // TODO: Connect to Supabase Storage for images in production
                onUploadMemberProof(tontine, currentUserName, uri.toString())
            }
        }
    )

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Supprimer la tontine") },
            text = { Text("Etes-vous sûr de supprimer cette tontine ?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteTontine(tontine)
                        showDeleteConfirmDialog = false
                    }
                ) {
                    Text("Oui", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tontine_item_${tontine.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Title and Delete Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tontine.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        SuggestionChip(
                            onClick = { },
                            label = { Text(tontine.frequency, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                labelColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        )
                        SuggestionChip(
                            onClick = { },
                            label = { Text("${members.size}/${tontine.membersCount} membres", fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                                labelColor = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        )
                    }
                }

                if (isUserTreasurer) {
                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.testTag("delete_tontine_btn_${tontine.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Supprimer tontine",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // Financial Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Cotisation individuelle", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text(
                        text = CurrencyUtils.formatFCFA(tontine.amountPerMember),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF007A5E)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Caisse Globale (Tour)", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text(
                        text = CurrencyUtils.formatFCFA(totalPot),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFCE1126)
                    )
                }
            }

            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // Turn Counter Controls & Beneficiary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Tour Actuel", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${tontine.currentTurn} / ${tontine.membersCount}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "(${tontine.frequency})",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                    }
                }

                if (isUserTreasurer) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onDecrementTurn(tontine) },
                            enabled = tontine.currentTurn > 1,
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    if (tontine.currentTurn > 1) MaterialTheme.colorScheme.secondaryContainer else Color.LightGray.copy(alpha = 0.2f),
                                    CircleShape
                                )
                        ) {
                            Icon(imageVector = Icons.Default.Remove, contentDescription = "Précédent", modifier = Modifier.size(16.dp))
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF007A5E), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${tontine.currentTurn}", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = {
                                val nextTurn = tontine.currentTurn + 1
                                val sorted = members.sortedBy { if (it.beneficiaryDate.isBlank()) "9999-12-31" else it.beneficiaryDate }
                                val nextBeneficiaryName = sorted.getOrNull(nextTurn - 1)?.name ?: tontine.nextBeneficiary
                                onIncrementTurn(tontine, nextBeneficiaryName)
                            },
                            enabled = tontine.currentTurn < tontine.membersCount && members.all { it.hasPaidCurrentTurn && it.isProofValidated } && isBeneficiaryProofUploaded,
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    if (tontine.currentTurn < tontine.membersCount && members.all { it.hasPaidCurrentTurn && it.isProofValidated } && isBeneficiaryProofUploaded) MaterialTheme.colorScheme.secondaryContainer else Color.LightGray.copy(alpha = 0.2f),
                                    CircleShape
                                )
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Suivant", modifier = Modifier.size(16.dp))
                        }
                    }
                } else {
                    Text(
                        text = "En attente du Trésorier",
                        style = MaterialTheme.typography.bodySmall,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        color = Color.Gray,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }

            // Expected Beneficiary and Due Date (Calculated)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFFDE7), RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFFFFF59D), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = Color(0xFFF57F17),
                    modifier = Modifier.size(18.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Bénéficiaire :",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF5D4037)
                        )
                        
                        var dropdownExpanded by remember { mutableStateOf(false) }
                        
                        Box {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable(enabled = isUserCreator || isUserTreasurer) { dropdownExpanded = true }
                                    .padding(horizontal = 4.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = tontine.nextBeneficiary,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFF57F17)
                                )
                                if (isUserCreator || isUserTreasurer) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Changer bénéficiaire",
                                        tint = Color(0xFFF57F17),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            
                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false }
                            ) {
                                members.forEach { member ->
                                    DropdownMenuItem(
                                        text = { Text(member.name) },
                                        onClick = {
                                            onSetBeneficiary(tontine, member.name)
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Date attendue :",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF5D4037)
                        )
                        Text(
                            text = turnDate,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF5D4037)
                        )
                    }

                    // Beneficiary Payout Proof section
                    Spacer(modifier = Modifier.height(6.dp))
                    var showBeneficiaryProofDialog by remember { mutableStateOf(false) }
                    
                    val beneficiaryPhotoPickerLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.PickVisualMedia(),
                        onResult = { uri ->
                            if (uri != null) {
                                onUploadBeneficiaryProof(tontine, tontine.nextBeneficiary, uri.toString())
                            }
                        }
                    )
                    
                    if (isBeneficiaryProofUploaded) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Preuve de paiement :",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF5D4037)
                            )
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFE8F5E9))
                                    .clickable { showBeneficiaryProofDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Voir le reçu",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                        
                        if (showBeneficiaryProofDialog && currentBeneficiaryMember?.beneficiaryProofUri != null) {
                            androidx.compose.ui.window.Dialog(onDismissRequest = { showBeneficiaryProofDialog = false }) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "Reçu de transfert - ${tontine.nextBeneficiary}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        )
                                        if (currentBeneficiaryMember.beneficiaryProofUri.startsWith("mock_")) {
                                            // Show a beautiful mock receipt details instead of a missing uri crash
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(Color.White, RoundedCornerShape(8.dp))
                                                    .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                                    .padding(16.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text("Statut: Payé (Validé)", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                                Text("Bénéficiaire: ${tontine.nextBeneficiary}")
                                                Text("Montant: ${String.format("%,.0f FCFA", totalPot)}")
                                                Text("Date: ${turnDate}")
                                                Text("Référence: TXN-TONT-2026-003")
                                            }
                                        } else {
                                            androidx.compose.foundation.Image(
                                                painter = rememberAsyncImagePainter(model = currentBeneficiaryMember.beneficiaryProofUri),
                                                contentDescription = "Preuve de paiement",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(300.dp)
                                                    .clip(RoundedCornerShape(8.dp)),
                                                contentScale = ContentScale.Fit
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        TextButton(onClick = { showBeneficiaryProofDialog = false }) {
                                            Text("Fermer")
                                        }
                                    }
                                }
                            }
                        }
                    } else if (isUserTreasurer) {
                        Button(
                            onClick = {
                                beneficiaryPhotoPickerLauncher.launch(
                                    androidx.activity.result.PickVisualMediaRequest(
                                        ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF57F17)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Envoyer au Bénéficiaire", color = Color.White, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Button: Gérer Membres
            if (isUserCreator || isUserTreasurer) {
                OutlinedButton(
                    onClick = { showMembersDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF007A5E)),
                    border = BorderStroke(1.dp, Color(0xFF007A5E))
                ) {
                    Icon(imageVector = Icons.Default.People, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Gérer Membres", fontWeight = FontWeight.Bold)
                }
            }

            // Section 1: Treasurer Election
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.HowToVote,
                                contentDescription = null,
                                tint = Color(0xFFE65100),
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "🗳️ Vote du Trésorier",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Crown Icon for elected treasurer
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.MilitaryTech, contentDescription = null, tint = Color(0xFFFBC02D), modifier = Modifier.size(16.dp))
                            Text(
                                text = electedTreasurerName,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100)
                            )
                        }
                    }

                    if (tontine.userVotedForName.isBlank()) {
                        Text(
                            text = "Votez pour élire le Trésorier de cette tontine :",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                        // List candidates
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            members.forEach { m ->
                                SuggestionChip(
                                    onClick = { onVoteForMember(tontine, m.name) },
                                    label = { Text("${m.name} (${m.votes})", fontSize = 10.sp) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = Color(0xFFE65100).copy(alpha = 0.08f),
                                        labelColor = Color(0xFFE65100)
                                    )
                                )
                            }
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(14.dp))
                            Text(
                                text = "Vous avez voté pour ${tontine.userVotedForName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Section 2: Cotisations turn status & payment proof uploads
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "💸 État des Cotisations (Tour ${tontine.currentTurn})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )

                    members.forEach { m ->
                        val isSelf = m.name == currentUserName
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = m.name + if (isSelf) " (Moi)" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (m.name == electedTreasurerName) {
                                        Text(
                                            text = "Trésorier",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFFEBC02D),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .background(Color(0xFFFFFDE7), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(text = m.phone, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Status badge
                                if (m.hasPaidCurrentTurn) {
                                    Text(
                                        text = "Payé ✅",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.Bold
                                    )
                                } else if (m.proofUri != null) {
                                    Text(
                                        text = "Preuve soumise ⏳",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFFE65100),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clickable {
                                            // Optional: click to review proof if treasurer
                                        }
                                    )
                                } else {
                                    Text(
                                        text = "Non Payé ❌",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFFCE1126),
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Interactive buttons
                                if (isSelf && !m.hasPaidCurrentTurn && m.proofUri == null) {
                                    Button(
                                        onClick = {
                                            photoPickerLauncher.launch(
                                                androidx.activity.result.PickVisualMediaRequest(
                                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                                )
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("Ajouter Preuve", fontSize = 10.sp, color = Color.White)
                                    }
                                }

                                // Confirmation for Treasurer/Creator
                                if ((isUserTreasurer || isUserCreator) && m.proofUri != null && !m.hasPaidCurrentTurn) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(
                                            onClick = { onRejectMemberPayment(tontine, m.name) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Close, contentDescription = "Rejeter", tint = Color.Red, modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(
                                            onClick = { onConfirmMemberPayment(tontine, m.name) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Check, contentDescription = "Confirmer", tint = Color(0xFF007A5E), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }

                        // Render proof preview if exists
                        if (m.proofUri != null && (isUserTreasurer || isUserCreator || isSelf)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 12.dp, top = 2.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
                                ) {
                                    androidx.compose.foundation.Image(
                                        painter = rememberAsyncImagePainter(model = m.proofUri),
                                        contentDescription = "Preuve de paiement",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                                Text("Capture d'écran du transfert MoMo", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            // Section 3: WhatsApp Reminders generator
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "💬 Relancer les membres par WhatsApp",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )

                    members.forEach { m ->
                        if (m.name != currentUserName) {
                            val isBeneficiary = m.name == tontine.nextBeneficiary
                            val reminderText = if (isBeneficiary) {
                                "Rappel: C'est ton tour de recevoir $totalPot FCFA dans ${tontine.name} le $turnDate. Prépare-toi !"
                            } else {
                                "Rappel: Cotisation de ${tontine.amountPerMember} FCFA pour ${tontine.name} due le $turnDate. Merci d'envoyer la preuve."
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = m.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Button(
                                    onClick = { sendWhatsAppMessage(context, m.phone, reminderText) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), // WhatsApp Green
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isBeneficiary) "Rappel Tour" else "Rappel Cotis", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showMembersDialog) {
        MembersManagementDialog(
            tontine = tontine,
            members = members,
            isUserAdmin = isUserCreator || isUserTreasurer,
            onDismiss = { showMembersDialog = false },
            onAddMember = { name, phone, date ->
                onAddMember(tontine, name, phone, date)
            },
            onRemoveMember = { member ->
                onRemoveMember(tontine, member)
            },
            onHandleJoinRequest = { name, phone, accept, date ->
                onHandleJoinRequest(tontine, name, phone, accept, date)
            }
        )
    }

    if (showSelectBeneficiaryDialog) {
        var dropdownExpanded by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showSelectBeneficiaryDialog = false },
            title = {
                Text(
                    text = "Bénéficiaire du Tour ${tontine.currentTurn + 1}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Veuillez choisir le bénéficiaire pour le prochain tour :",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { dropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = selectedBeneficiaryName.ifBlank { "Sélectionner un membre" })
                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        
                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            members.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(m.name) },
                                    onClick = {
                                        selectedBeneficiaryName = m.name
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onIncrementTurn(tontine, selectedBeneficiaryName)
                        showSelectBeneficiaryDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E)),
                    enabled = selectedBeneficiaryName.isNotBlank()
                ) {
                    Text("Valider", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSelectBeneficiaryDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }
}

fun calculateNextBeneficiaryDateIso(startDateStr: String, frequency: String, index: Int): String {
    return try {
        val formatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd")
        val date = java.time.LocalDate.parse(startDateStr, formatter)
        val nextDate = when (frequency.lowercase()) {
            "hebdo", "hebdomadaire" -> date.plusWeeks(index.toLong())
            else -> date.plusMonths(index.toLong())
        }
        nextDate.format(formatter)
    } catch (e: Exception) {
        startDateStr
    }
}

@Composable
fun MembersManagementDialog(
    tontine: Tontine,
    members: List<TontineMember>,
    isUserAdmin: Boolean,
    onDismiss: () -> Unit,
    onAddMember: (String, String, String) -> Unit,
    onRemoveMember: (TontineMember) -> Unit,
    onHandleJoinRequest: (String, String, Boolean, String) -> Unit = { _, _, _, _ -> }
) {
    val context = LocalContext.current
    var newMemberName by remember { mutableStateOf("") }
    var newMemberPhone by remember { mutableStateOf("") }
    var newMemberBeneficiaryDate by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf("") }

    // Auto-suggest next date when dialog opens or members count changes
    LaunchedEffect(members.size) {
        newMemberBeneficiaryDate = calculateNextBeneficiaryDateIso(tontine.startDate, tontine.frequency, members.size)
    }

    val onPickDate = {
        try {
            val parts = newMemberBeneficiaryDate.split("-")
            val y = parts[0].toInt()
            val m = parts[1].toInt() - 1
            val d = parts[2].toInt()
            android.app.DatePickerDialog(context, { _, year, month, dayOfMonth ->
                newMemberBeneficiaryDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
            }, y, m, d).show()
        } catch (e: Exception) {
            android.app.DatePickerDialog(context, { _, year, month, dayOfMonth ->
                newMemberBeneficiaryDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
            }, 2026, 6, 17).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Gérer les Membres",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = tontine.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                val pendingRequests = tontine.getJoinRequestsList().filter { it.status == "En attente" }
                if (pendingRequests.isNotEmpty() && isUserAdmin) {
                    Text("Demandes d'adhésion (${pendingRequests.size}) :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color(0xFF007A5E))
                    pendingRequests.forEach { req ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFE0F2F1), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(req.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                Text(req.phone, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(
                                    onClick = {
                                        val nextDate = calculateNextBeneficiaryDateIso(tontine.startDate, tontine.frequency, members.size)
                                        onHandleJoinRequest(req.name, req.phone, true, nextDate)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Accepter", fontSize = 10.sp, color = Color.White)
                                }
                                Button(
                                    onClick = {
                                        onHandleJoinRequest(req.name, req.phone, false, "")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFCE1126)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Refuser", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }
                    }
                    Divider()
                }

                if (isUserAdmin) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Ajouter un membre", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            
                            OutlinedTextField(
                                value = newMemberName,
                                onValueChange = { newMemberName = it; inputError = "" },
                                label = { Text("Nom complet") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = newMemberPhone,
                                onValueChange = { newMemberPhone = it; inputError = "" },
                                label = { Text("WhatsApp (2376XXXXXXXX)") },
                                placeholder = { Text("Ex: 237677889900") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = newMemberBeneficiaryDate,
                                onValueChange = { /* Read only */ },
                                label = { Text("Date de bénéficiaire (Unique)") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = onPickDate) {
                                        Icon(imageVector = Icons.Default.Event, contentDescription = "Choisir une date")
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            if (inputError.isNotBlank()) {
                                Text(inputError, color = Color.Red, style = MaterialTheme.typography.labelSmall)
                            }

                            Button(
                                onClick = {
                                    val cleanPhone = newMemberPhone.replace(" ", "").replace("+", "")
                                    if (newMemberName.trim().isBlank()) {
                                        inputError = "Veuillez entrer un nom."
                                    } else if (cleanPhone.length != 12 || !cleanPhone.startsWith("237")) {
                                        inputError = "Le format doit être 2376XXXXXXXX (12 chiffres)."
                                    } else if (members.any { it.beneficiaryDate == newMemberBeneficiaryDate }) {
                                        inputError = "Cette date de bénéficiaire est déjà attribuée."
                                    } else {
                                        onAddMember(newMemberName.trim(), cleanPhone, newMemberBeneficiaryDate)
                                        newMemberName = ""
                                        newMemberPhone = ""
                                        inputError = ""
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E))
                            ) {
                                Text("Ajouter au groupe", color = Color.White)
                            }
                        }
                    }
                }

                Divider()

                Text("Liste des membres (${members.size}) :", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(members) { m ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(m.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                    // Badge
                                    val badgeColor = when (m.role) {
                                        "Créateur" -> Color(0xFF007A5E)
                                        "Trésorier" -> Color(0xFFE65100)
                                        else -> Color.Gray
                                    }
                                    Text(
                                        text = m.role,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier
                                            .background(badgeColor, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                Text(m.phone, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }

                            if (isUserAdmin && m.role != "Créateur") {
                                IconButton(
                                    onClick = { onRemoveMember(m) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Retirer", tint = Color.Red, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Fermer", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun CreateTontineDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, Double, Int, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var membersStr by remember { mutableStateOf("10") }
    var frequency by remember { mutableStateOf("Mensuel") }
    var startDate by remember { mutableStateOf(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())) }
    var visibility by remember { mutableStateOf("Publique") } // "Publique", "Privée"
    var ville by remember { mutableStateOf("Douala") }

    var isError by remember { mutableStateOf(false) }

    val frequencies = listOf("Mensuel", "Hebdomadaire", "Bimensuel", "Annuel")
    val cities = listOf("Douala", "Yaoundé", "Bafoussam", "Garoua", "Kribi")

    var cityDropdownExpanded by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val calendar = java.util.Calendar.getInstance()
    val datePickerDialog = android.app.DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val cal = java.util.Calendar.getInstance().apply {
                set(year, month, dayOfMonth)
            }
            startDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(cal.time)
        },
        calendar.get(java.util.Calendar.YEAR),
        calendar.get(java.util.Calendar.MONTH),
        calendar.get(java.util.Calendar.DAY_OF_MONTH)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Créer une Tontine",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; isError = false },
                    label = { Text("Nom de la tontine") },
                    placeholder = { Text("Ex: Les Amis Solidaires") },
                    modifier = Modifier.fillMaxWidth().testTag("create_tontine_name_input"),
                    singleLine = true,
                    isError = isError && name.isEmpty()
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it; isError = false },
                    label = { Text("Cotisation par membre (FCFA)") },
                    placeholder = { Text("Ex: 50000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("create_tontine_amount_input"),
                    singleLine = true,
                    isError = isError && (amountStr.toDoubleOrNull() ?: 0.0) <= 0.0
                )

                OutlinedTextField(
                    value = membersStr,
                    onValueChange = { membersStr = it; isError = false },
                    label = { Text("Nombre de membres") },
                    placeholder = { Text("Ex: 10") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("create_tontine_members_input"),
                    singleLine = true,
                    isError = isError && (membersStr.toIntOrNull() ?: 0) <= 0
                )

                OutlinedTextField(
                    value = startDate,
                    onValueChange = {},
                    label = { Text("Date de début") },
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { datePickerDialog.show() }) {
                            Icon(Icons.Default.DateRange, contentDescription = "Choisir une date")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { datePickerDialog.show() },
                    isError = isError && startDate.isEmpty()
                )

                // Visibility selector
                Text(
                    text = "Visibilité :",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Publique", "Privée").forEach { vis ->
                        val isSelected = visibility == vis
                        SuggestionChip(
                            onClick = { visibility = vis },
                            label = { Text(vis) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isSelected) Color(0xFF007A5E) else MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // City Selector
                Text(
                    text = "Ville d'origine :",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Box {
                    OutlinedButton(
                        onClick = { cityDropdownExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(ville)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    }
                    DropdownMenu(
                        expanded = cityDropdownExpanded,
                        onDismissRequest = { cityDropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.6f)
                    ) {
                        cities.forEach { city ->
                            DropdownMenuItem(
                                text = { Text(city) },
                                onClick = {
                                    ville = city
                                    cityDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Text(
                    text = "Fréquence de cotisation :",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    frequencies.take(3).forEach { freq ->
                        val isSelected = frequency == freq
                        SuggestionChip(
                            onClick = { frequency = freq },
                            label = { Text(freq, fontSize = 11.sp) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = if (isSelected) Color(0xFF007A5E) else MaterialTheme.colorScheme.surfaceVariant,
                                labelColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Commission TontiDette: 1% nous aide à rester gratuit 💚",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF007A5E),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                if (isError) {
                    Text(
                        text = "Veuillez remplir correctement tous les champs.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    val members = membersStr.toIntOrNull() ?: 0
                    if (name.trim().isEmpty() || amount <= 0.0 || members <= 0 || startDate.trim().isEmpty()) {
                        isError = true
                    } else {
                        onConfirm(name.trim(), amount, members, frequency, startDate.trim(), visibility, ville)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF007A5E)
                ),
                modifier = Modifier.testTag("create_tontine_confirm_btn")
            ) {
                Text("Créer", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("create_tontine_cancel_btn")
            ) {
                Text("Annuler")
            }
        }
    )
}
