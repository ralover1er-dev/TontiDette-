package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Debt
import com.example.ui.utils.CurrencyUtils
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DebtsScreen(
    debts: List<Debt>,
    onAddDebt: (String, Double, Boolean, String, String, String, String, Boolean) -> Unit,
    onTogglePaid: (Debt) -> Unit,
    onDeleteDebt: (Debt) -> Unit,
    userProfileName: String = "Utilisateur TontiDette",
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val tabs = listOf("Je dois", "On me doit")

    // Filter debts based on selected sub-tab
    val filteredDebts = debts.filter {
        if (selectedTabIndex == 0) it.isJeDois else !it.isJeDois
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(8.dp))

            // Sub tabs for Je Dois / On me Doit
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = if (selectedTabIndex == 0) Color(0xFFCE1126) else Color(0xFF007A5E)
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) {
                                    if (index == 0) Color(0xFFCE1126) else Color(0xFF007A5E)
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (filteredDebts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (selectedTabIndex == 0) Icons.Default.ThumbUp else Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = if (selectedTabIndex == 0) "Super ! Vous ne devez rien pour l'instant."
                                   else "Aucun crédit actif enregistré.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Cliquez sur le bouton '+' pour ajouter une ligne.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredDebts, key = { it.id }) { debt ->
                        DebtCardItem(
                            debt = debt,
                            onTogglePaid = onTogglePaid,
                            onDeleteDebt = onDeleteDebt,
                            onSendReminder = { d ->
                                sendWhatsAppReminder(context, d, userProfileName)
                            }
                        )
                    }
                }
            }
        }

        // FAB to add new debt
        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = if (selectedTabIndex == 0) Color(0xFFCE1126) else Color(0xFF007A5E),
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 80.dp, end = 16.dp)
                .testTag("add_debt_fab"),
            shape = CircleShape
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Ajouter une dette")
        }
    }

    // Dialog for adding a new Debt
    if (showAddDialog) {
        AddDebtDialog(
            defaultIsJeDois = selectedTabIndex == 0,
            onDismiss = { showAddDialog = false },
            onConfirm = { name, amount, isJeDois, phone, dateRemb, whatsappNum, paid ->
                val currentDateStr = SimpleDateFormat("dd MMM 2026", Locale.FRENCH).format(Date())
                onAddDebt(name, amount, isJeDois, currentDateStr, phone, dateRemb, whatsappNum, paid)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun DebtCardItem(
    debt: Debt,
    onTogglePaid: (Debt) -> Unit,
    onDeleteDebt: (Debt) -> Unit,
    onSendReminder: (Debt) -> Unit
) {
    val cardBg = if (debt.isPaid) {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("debt_item_${debt.id}"),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (debt.isPaid) 0.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Checkbox to mark as paid
                Checkbox(
                    checked = debt.isPaid,
                    onCheckedChange = { onTogglePaid(debt) },
                    colors = CheckboxDefaults.colors(
                        checkedColor = if (debt.isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E)
                    ),
                    modifier = Modifier.testTag("debt_checkbox_${debt.id}")
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = debt.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textDecoration = if (debt.isPaid) TextDecoration.LineThrough else TextDecoration.None,
                        color = if (debt.isPaid) Color.Gray else MaterialTheme.colorScheme.onSurface
                    )
                    
                    Text(
                        text = "${if (debt.isJeDois) "Je dois" else "On me doit"} • Créé le ${debt.date}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )

                    if (debt.dateRemboursement.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Event,
                                contentDescription = null,
                                tint = if (debt.isPaid) Color.Gray else Color(0xFFD32F2F),
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "Échéance : ${debt.dateRemboursement}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = if (debt.isPaid) Color.Gray else Color(0xFFD32F2F)
                            )
                        }
                    }

                    if (debt.phoneNumber.isNotEmpty()) {
                        Text(
                            text = "Tél: ${debt.phoneNumber}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = CurrencyUtils.formatFCFA(debt.amount),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        textDecoration = if (debt.isPaid) TextDecoration.LineThrough else TextDecoration.None,
                        color = if (debt.isPaid) {
                            Color.Gray
                        } else {
                            if (debt.isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E)
                        }
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Delete button
                        IconButton(
                            onClick = { onDeleteDebt(debt) },
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f), CircleShape)
                                .testTag("delete_debt_btn_${debt.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Supprimer",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Dedicated WhatsApp Rappel button for "On me doit" debts that are not yet paid
            if (!debt.isPaid && !debt.isJeDois && debt.phoneNumber.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onSendReminder(debt) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF25D366), // WhatsApp Green
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .testTag("whatsapp_reminder_btn_${debt.id}")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Relancer sur WhatsApp",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Rappeler la dette sur WhatsApp",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddDebtDialog(
    defaultIsJeDois: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (String, Double, Boolean, String, String, String, Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var isJeDois by remember { mutableStateOf(defaultIsJeDois) }
    var phone by remember { mutableStateOf("") }
    var dateRemboursement by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var numeroWhatsApp by remember { mutableStateOf("") }

    var isError by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val calendar = java.util.Calendar.getInstance()
    val datePickerDialog = android.app.DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val cal = java.util.Calendar.getInstance().apply {
                set(year, month, dayOfMonth)
            }
            dateRemboursement = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
        },
        calendar.get(java.util.Calendar.YEAR),
        calendar.get(java.util.Calendar.MONTH),
        calendar.get(java.util.Calendar.DAY_OF_MONTH)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Ajouter une Dette",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Selector Row (Je dois / On me doit)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isJeDois = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isJeDois) Color(0xFFCE1126) else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isJeDois) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Je dois", fontSize = 13.sp)
                    }

                    Button(
                        onClick = { isJeDois = false },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isJeDois) Color(0xFF007A5E) else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (!isJeDois) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("On me doit", fontSize = 13.sp)
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; isError = false },
                    label = { Text("Nom de la personne") },
                    placeholder = { Text("Ex: Papa Fomekong") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_debt_name_input"),
                    singleLine = true,
                    isError = isError && name.isEmpty()
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it; isError = false },
                    label = { Text("Montant (FCFA)") },
                    placeholder = { Text("Ex: 25000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_debt_amount_input"),
                    singleLine = true,
                    isError = isError && (amountStr.toDoubleOrNull() ?: 0.0) <= 0.0
                )

                OutlinedTextField(
                    value = dateRemboursement,
                    onValueChange = {},
                    label = { Text("Date de remboursement") },
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { datePickerDialog.show() }) {
                            Icon(Icons.Default.DateRange, contentDescription = "Choisir une date")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { datePickerDialog.show() }
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() || it == '+' }
                        val justDigits = digits.filter { it.isDigit() }
                        if (justDigits.length == 9 && !digits.startsWith("+237") && !digits.startsWith("237")) {
                            phone = "+237$justDigits"
                        } else {
                            phone = digits
                        }
                    },
                    label = { Text("Numéro WhatsApp (+237)") },
                    placeholder = { Text("Ex: +237691234567") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_debt_phone_input"),
                    singleLine = true
                )

                if (isError) {
                    Text(
                        text = "Veuillez remplir le nom et spécifier un montant valide.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountStr.toDoubleOrNull() ?: 0.0
                    if (name.trim().isEmpty() || amount <= 0.0) {
                        isError = true
                    } else {
                        var formattedPhone = phone.trim().replace(" ", "")
                        if (formattedPhone.isNotEmpty()) {
                            if (!formattedPhone.startsWith("+") && !formattedPhone.startsWith("237")) {
                                if (formattedPhone.length == 9) {
                                    formattedPhone = "237$formattedPhone"
                                }
                            }
                        }
                        onConfirm(name.trim(), amount, isJeDois, formattedPhone, dateRemboursement, formattedPhone, false)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E)
                ),
                modifier = Modifier.testTag("add_debt_confirm_btn")
            ) {
                Text("Ajouter", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("add_debt_cancel_btn")
            ) {
                Text("Annuler")
            }
        }
    )
}

/**
 * Fires an Android ACTION_VIEW Intent to send a styled WhatsApp reminder message with the sender's profile name.
 */
fun sendWhatsAppReminder(context: Context, debt: Debt, userProfileName: String = "Utilisateur TontiDette") {
    val targetPhone = if (debt.numeroWhatsApp.isNotEmpty()) debt.numeroWhatsApp else debt.phoneNumber
    if (targetPhone.isEmpty()) {
        Toast.makeText(context, "Numéro de téléphone non renseigné sur cette dette.", Toast.LENGTH_SHORT).show()
        return
    }

    var cleanPhone = targetPhone.replace(" ", "").replace("+", "")
    if (!cleanPhone.startsWith("237") && cleanPhone.length == 9) {
        cleanPhone = "237$cleanPhone"
    }

    val formattedAmount = CurrencyUtils.formatFCFA(debt.amount)
    val senderName = if (userProfileName.isNotBlank()) userProfileName else "Ton créancier"

    val message = "Bonjour ${debt.name}, c'est $senderName 👋\n\nJe te rappelle gentiment que la date d'échéance pour le remboursement de la dette de $formattedAmount est arrivée (${if (debt.dateRemboursement.isNotEmpty()) debt.dateRemboursement else "aujourd'hui"}).\n\nMerci de procéder au virement (Orange Money / MTN Mobile Money) dès que possible. 🙏\n\n- Envoyé via l'application TontiDette Cameroun"

    try {
        val url = "https://api.whatsapp.com/send?phone=${cleanPhone}&text=${URLEncoder.encode(message, "UTF-8")}"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Impossible d'ouvrir WhatsApp. Vérifiez que l'application est installée.", Toast.LENGTH_LONG).show()
    }
}
