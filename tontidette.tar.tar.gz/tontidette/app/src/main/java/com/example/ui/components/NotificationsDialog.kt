package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Debt
import com.example.data.Tontine
import com.example.ui.screens.sendWhatsAppReminder
import com.example.ui.utils.CurrencyUtils

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val type: NotificationType,
    val debt: Debt? = null,
    val tontine: Tontine? = null,
    val date: String = ""
)

enum class NotificationType {
    JE_DOIS_DUE,
    ON_ME_DOIT_REMINDER,
    TONTINE_RECUPERATION,
    TONTINE_COTISATION
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsDialog(
    debts: List<Debt>,
    tontines: List<Tontine>,
    userProfileName: String,
    userPhone: String,
    onDismiss: () -> Unit,
    onNavigateToDebts: () -> Unit,
    onNavigateToTontines: () -> Unit
) {
    val context = LocalContext.current

    val notifications = remember(debts, tontines, userProfileName, userPhone) {
        val list = mutableListOf<NotificationItem>()
        val cleanUserPhone = userPhone.replace(" ", "").replace("+", "")

        // 1. Debts Notifications
        debts.filter { !it.isPaid }.forEach { debt ->
            if (debt.isJeDois) {
                list.add(
                    NotificationItem(
                        id = "debt_je_dois_${debt.id}",
                        title = "Dette à rembourser",
                        message = "Vous devez rembourser ${CurrencyUtils.formatFCFA(debt.amount)} à ${debt.name}.${if (debt.dateRemboursement.isNotEmpty()) " Échéance: ${debt.dateRemboursement}" else ""}",
                        type = NotificationType.JE_DOIS_DUE,
                        debt = debt,
                        date = debt.dateRemboursement.ifEmpty { debt.date }
                    )
                )
            } else {
                list.add(
                    NotificationItem(
                        id = "debt_on_me_doit_${debt.id}",
                        title = "Rappel de crédit (On vous doit)",
                        message = "${debt.name} vous doit ${CurrencyUtils.formatFCFA(debt.amount)}.${if (debt.dateRemboursement.isNotEmpty()) " Échéance: ${debt.dateRemboursement}" else ""}",
                        type = NotificationType.ON_ME_DOIT_REMINDER,
                        debt = debt,
                        date = debt.dateRemboursement.ifEmpty { debt.date }
                    )
                )
            }
        }

        // 2. Tontines Notifications (Jour de récupération / Cotisation)
        tontines.forEach { tontine ->
            val members = tontine.getMembersList()
            val userMember = members.find { m ->
                (cleanUserPhone.isNotBlank() && m.phone.replace(" ", "").replace("+", "") == cleanUserPhone) ||
                m.name.equals(userProfileName, ignoreCase = true)
            }

            if (userMember != null) {
                val totalPot = tontine.amountPerMember * (members.size.coerceAtLeast(1))
                if (tontine.nextBeneficiary.equals(userMember.name, ignoreCase = true) ||
                    tontine.nextBeneficiary.equals(userProfileName, ignoreCase = true)
                ) {
                    list.add(
                        NotificationItem(
                            id = "tontine_recup_${tontine.id}",
                            title = "Jour de Récupération Tontine 🎉",
                            message = "C'est votre tour de récupérer la cagnotte de ${CurrencyUtils.formatFCFA(totalPot)} dans '${tontine.name}' !",
                            type = NotificationType.TONTINE_RECUPERATION,
                            tontine = tontine,
                            date = "Aujourd'hui"
                        )
                    )
                } else {
                    list.add(
                        NotificationItem(
                            id = "tontine_coti_${tontine.id}",
                            title = "Rappel de Cotisation",
                            message = "N'oubliez pas de verser votre cotisation de ${CurrencyUtils.formatFCFA(tontine.amountPerMember)} pour la tontine '${tontine.name}'.",
                            type = NotificationType.TONTINE_COTISATION,
                            tontine = tontine,
                            date = tontine.frequency
                        )
                    )
                }
            }
        }

        list
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF007A5E).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = Color(0xFF007A5E),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = "Centre de Notifications",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF004D40)
                )
            }
        },
        text = {
            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF007A5E),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "Toutes vos échéances sont à jour !",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Aucun rappel en attente pour le moment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(notifications, key = { it.id }) { item ->
                        val cardBg = when (item.type) {
                            NotificationType.JE_DOIS_DUE -> Color(0xFFFFF2F2)
                            NotificationType.ON_ME_DOIT_REMINDER -> Color(0xFFE8F5E9)
                            NotificationType.TONTINE_RECUPERATION -> Color(0xFFFFFDE7)
                            NotificationType.TONTINE_COTISATION -> Color(0xFFF3E5F5)
                        }
                        val iconColor = when (item.type) {
                            NotificationType.JE_DOIS_DUE -> Color(0xFFCE1126)
                            NotificationType.ON_ME_DOIT_REMINDER -> Color(0xFF007A5E)
                            NotificationType.TONTINE_RECUPERATION -> Color(0xFFF57F17)
                            NotificationType.TONTINE_COTISATION -> Color(0xFF7B1FA2)
                        }
                        val iconVec = when (item.type) {
                            NotificationType.JE_DOIS_DUE -> Icons.Default.Warning
                            NotificationType.ON_ME_DOIT_REMINDER -> Icons.Default.AccountBalanceWallet
                            NotificationType.TONTINE_RECUPERATION -> Icons.Default.EmojiEvents
                            NotificationType.TONTINE_COTISATION -> Icons.Default.GroupWork
                        }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = iconVec,
                                        contentDescription = null,
                                        tint = iconColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                Text(
                                    text = item.message,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                // Action Buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    val debtItem = item.debt
                                    val tontineItem = item.tontine

                                    if (item.type == NotificationType.ON_ME_DOIT_REMINDER && debtItem != null) {
                                        Button(
                                            onClick = {
                                                sendWhatsAppReminder(context, debtItem, userProfileName)
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFF25D366),
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Send,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Relancer sur WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    } else if (debtItem != null) {
                                        TextButton(
                                            onClick = {
                                                onDismiss()
                                                onNavigateToDebts()
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Voir dans Dettes", fontSize = 12.sp, color = Color(0xFF007A5E))
                                        }
                                    } else if (tontineItem != null) {
                                        TextButton(
                                            onClick = {
                                                onDismiss()
                                                onNavigateToTontines()
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("Voir la Tontine", fontSize = 12.sp, color = Color(0xFF007A5E))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_notifications_btn")
            ) {
                Text("Fermer", fontWeight = FontWeight.Bold, color = Color(0xFF007A5E))
            }
        }
    )
}
