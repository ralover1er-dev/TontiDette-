package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtDao {
    @Query("SELECT * FROM debts ORDER BY date DESC")
    fun getAllDebts(): Flow<List<Debt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: Debt)

    @Update
    suspend fun updateDebt(debt: Debt)

    @Delete
    suspend fun deleteDebt(debt: Debt)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteDebtById(id: Int)

    @Query("DELETE FROM debts")
    suspend fun deleteAllDebts()
}

@Dao
interface TontineDao {
    @Query("SELECT * FROM tontines ORDER BY id DESC")
    fun getAllTontines(): Flow<List<Tontine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTontine(tontine: Tontine)

    @Update
    suspend fun updateTontine(tontine: Tontine)

    @Delete
    suspend fun deleteTontine(tontine: Tontine)

    @Query("DELETE FROM tontines")
    suspend fun deleteAllTontines()
}

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileDirect(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: UserProfile)
}
