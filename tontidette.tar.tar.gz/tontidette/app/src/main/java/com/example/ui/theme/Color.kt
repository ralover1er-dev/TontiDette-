package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cameroon Brand Colors
val CameroonGreen = Color(0xFF007A5E)
val CameroonRed = Color(0xFFCE1126)
val CameroonYellow = Color(0xFFFCD116)

// Light Theme Palette
val ForestPrimary = Color(0xFF007A5E)
val ForestSecondary = Color(0xFFCE1126)
val GoldAccent = Color(0xFFFCD116)
val LightBackground = Color(0xFFF6F9F7) // Soft off-white with organic green tint
val LightSurface = Color(0xFFFFFFFF)
val OnLightText = Color(0xFF101C17) // Dark deep forest charcoal for great contrast

// Dark Theme Palette
val Green80 = Color(0xFF4EDCB5)
val Red80 = Color(0xFFFF8B94)
val DarkBackground = Color(0xFF0E1612) // Very dark green-charcoal
val DarkSurface = Color(0xFF17221E)
val OnDarkText = Color(0xFFE2EBE6)
