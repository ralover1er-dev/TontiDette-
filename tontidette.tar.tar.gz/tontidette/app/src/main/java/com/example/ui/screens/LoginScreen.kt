package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLogin: (name: String, phone: String, ville: String, useWhatsApp: Boolean) -> Unit,
    onNavigateToRegister: () -> Unit,
    modifier: Modifier = Modifier
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var useWhatsApp by remember { mutableStateOf(true) }
    var selectedCity by remember { mutableStateOf("Douala") }
    var dropdownExpanded by remember { mutableStateOf(false) }

    val cities = listOf(
        "Douala", "Yaoundé", "Bafoussam", "Garoua", "Bamenda", 
        "Maroua", "Buea", "Nkongsamba", "Ngaoundéré", "Kribi"
    )

    val cleanDigits = phone.filter { it.isDigit() }
    val isPhoneValid = phone.length == 12 && phone.startsWith("2376")
    val phoneError = phone.isNotEmpty() && !isPhoneValid
    val isLoginEnabled = name.trim().isNotEmpty() && isPhoneValid

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF00382B)) // Deep elegant Cameroonian green
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // App Branding Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "TontiDette",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFFCD116) // Gold
                )
                // Cameroonian Flag Badge
                Row(
                    modifier = Modifier
                        .size(32.dp, 20.dp)
                        .clip(RoundedCornerShape(2.dp))
                ) {
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFF007A5E))) // Green
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(Color(0xFFCE1126)), // Red
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFFCD116),
                            modifier = Modifier.size(8.dp)
                        )
                    }
                    Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFFCD116))) // Yellow
                }
            }

            Text(
                text = "Connexion à votre compte existant",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Entrez vos identifiants pour retrouver toutes vos tontines et vos dettes associées.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Login Form Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_card"),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF007A5E).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Login,
                                contentDescription = null,
                                tint = Color(0xFF007A5E),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = "Se connecter",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF005A45)
                        )
                    }

                    // Profile Name Input
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nom de profil / Nom complet") },
                        placeholder = { Text("Ex: Lesly Zoyem ou Papa Fomekong") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color(0xFF007A5E)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF007A5E),
                            focusedLabelColor = Color(0xFF007A5E)
                        )
                    )

                    // Phone Number Input
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }
                            if (digits.length == 9 && !digits.startsWith("237")) {
                                phone = "237$digits"
                            } else {
                                phone = digits
                            }
                        },
                        label = { Text("Numéro de téléphone (2376XXXXXXXX)") },
                        placeholder = { Text("Ex: 237691234567") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                tint = Color(0xFF007A5E)
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_phone_input"),
                        singleLine = true,
                        isError = phoneError,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF007A5E),
                            focusedLabelColor = Color(0xFF007A5E)
                        )
                    )
                    if (phoneError) {
                        Text(
                            text = "Le numéro doit comporter 12 chiffres (Ex: 237691234567)",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }

                    // Ville Selection Dropdown
                    Column {
                        Text(
                            text = "Ville :",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { dropdownExpanded = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("login_city_button"),
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedCity, style = MaterialTheme.typography.bodyLarge)
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.8f)
                            ) {
                                cities.forEach { city ->
                                    DropdownMenuItem(
                                        text = { Text(city) },
                                        onClick = {
                                            selectedCity = city
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // WhatsApp Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { useWhatsApp = !useWhatsApp }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Activer les rappels WhatsApp",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Switch(
                            checked = useWhatsApp,
                            onCheckedChange = { useWhatsApp = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF25D366)
                            )
                        )
                    }

                    // Sync Explanation Box
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFF007A5E),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "En vous connectant avec votre nom et numéro, toutes vos tontines et dettes enregistrées sous ce numéro seront automatiquement restaurées.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF004D40)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Submit Login Button
                    Button(
                        onClick = {
                            if (isLoginEnabled) {
                                val cleanPhone = phone.replace(" ", "").replace("+", "")
                                onLogin(name.trim(), cleanPhone, selectedCity, useWhatsApp)
                            }
                        },
                        enabled = isLoginEnabled,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF007A5E),
                            disabledContainerColor = Color.Gray.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("login_submit_btn")
                    ) {
                        Text(
                            text = "Se connecter",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Option to register / switch to account creation
                    TextButton(
                        onClick = onNavigateToRegister,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("switch_to_register_btn")
                    ) {
                        Text(
                            text = "Vous n'avez pas encore de compte ? S'inscrire",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF007A5E)
                        )
                    }
                }
            }
        }
    }
}
