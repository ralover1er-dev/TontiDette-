package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Debt
import com.example.data.Tontine
import com.example.data.TontiDetteRepository
import com.example.data.UserProfile
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class TontiDetteViewModel(private val repository: TontiDetteRepository) : ViewModel() {

    init {
        // Pre-populate database with Cameroonian-themed dummy data on first run
        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }
    }

    val profile: StateFlow<UserProfile?> = repository.userProfile
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val debts: StateFlow<List<Debt>> = repository.allDebts
        .combine(repository.userProfile) { list, prof ->
            if (prof == null || !prof.isConfigured) {
                emptyList()
            } else {
                val uId = prof.phone.replace(" ", "").replace("+", "")
                list.filter { it.userId == uId || it.userId == "" }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val tontines: StateFlow<List<Tontine>> = repository.allTontines
        .combine(repository.userProfile) { list, prof ->
            if (prof == null || !prof.isConfigured) {
                emptyList()
            } else {
                val uId = prof.phone.replace(" ", "").replace("+", "")
                val uName = prof.name
                list.filter { t ->
                    t.visibility == "Publique" || t.visibility == "Public" ||
                    t.userId == uId ||
                    t.userId == "" ||
                    t.getMembersList().any { m ->
                        (uId.isNotBlank() && m.phone.replace(" ", "").replace("+", "") == uId) ||
                        (uName.isNotBlank() && m.name.equals(uName, ignoreCase = true))
                    }
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Reactive computation of total I owe (Je dois)
    val totalJeDois: StateFlow<Double> = debts
        .map { list ->
            list.filter { it.isJeDois && !it.isPaid }.sumOf { it.amount }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    // Reactive computation of total owed to me (On me doit)
    val totalOnMeDoit: StateFlow<Double> = debts
        .map { list ->
            list.filter { !it.isJeDois && !it.isPaid }.sumOf { it.amount }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    // Debt actions
    fun addDebt(
        name: String,
        amount: Double,
        isJeDois: Boolean,
        date: String,
        phoneNumber: String,
        dateRemboursement: String = "",
        numeroWhatsApp: String = "",
        estRemboursee: Boolean = false
    ) {
        viewModelScope.launch {
            val uId = profile.value?.phone?.replace(" ", "")?.replace("+", "") ?: ""
            repository.insertDebt(
                Debt(
                    name = name,
                    amount = amount,
                    isJeDois = isJeDois,
                    date = date,
                    phoneNumber = phoneNumber,
                    isPaid = estRemboursee,
                    dateRemboursement = dateRemboursement.ifBlank { date },
                    numeroWhatsApp = numeroWhatsApp.ifBlank { phoneNumber },
                    estRemboursee = estRemboursee,
                    userId = uId
                )
            )
        }
    }

    fun toggleDebtPayment(debt: Debt) {
        viewModelScope.launch {
            val nextState = !debt.isPaid
            repository.updateDebt(debt.copy(isPaid = nextState, estRemboursee = nextState))
        }
    }

    fun deleteDebt(debt: Debt) {
        viewModelScope.launch {
            repository.deleteDebt(debt)
        }
    }

    // Tontine actions
    private fun serializeMembersList(members: List<com.example.data.TontineMember>): String {
        return members.joinToString("|") {
            "${it.name};${it.phone};${it.role};${it.hasPaidCurrentTurn};${it.votes};${it.proofUri ?: "null"};${it.isProofValidated};${it.beneficiaryDate.ifBlank { "2026-07-17" }};${it.beneficiaryProofUri ?: "null"}"
        }
    }

    private fun calculateBeneficiaryForTurn(members: List<com.example.data.TontineMember>, turn: Int): String {
        if (members.isEmpty()) return "Aucun membre"
        // Sort by beneficiaryDate ascending to assign turns automatically
        val sorted = members.sortedBy { if (it.beneficiaryDate.isBlank()) "9999-12-31" else it.beneficiaryDate }
        val index = (turn - 1).coerceIn(0, sorted.size - 1)
        return sorted[index].name
    }

    fun addTontine(name: String, amountPerMember: Double, currentTurn: Int, membersCount: Int, frequency: String, startDate: String = "2026-07-17") {
        viewModelScope.launch {
            val userName = profile.value?.name ?: "Lesly Zoyem"
            val userPhone = profile.value?.phone ?: "+237 677 88 99 00"
            val cleanPhone = userPhone.replace(" ", "").replace("+", "")
            val firstMember = com.example.data.TontineMember(
                name = userName,
                phone = cleanPhone,
                role = "Créateur",
                hasPaidCurrentTurn = false,
                votes = 0,
                beneficiaryDate = startDate
            )
            val membersSerialized = serializeMembersList(listOf(firstMember))
            
            repository.insertTontine(
                Tontine(
                    name = name,
                    amountPerMember = amountPerMember,
                    currentTurn = 1,
                    membersCount = membersCount,
                    frequency = frequency,
                    startDate = startDate,
                    nextBeneficiary = userName,
                    membersSerialized = membersSerialized,
                    userId = cleanPhone
                )
            )
        }
    }

    // Helper for legacy 5-param override signature
    fun addTontine(name: String, amountPerMember: Double, currentTurn: Int, membersCount: Int, frequency: String) {
        addTontine(name, amountPerMember, currentTurn, membersCount, frequency, "2026-07-17")
    }

    fun addTontineWithDateAndVisibility(
        name: String,
        amountPerMember: Double,
        membersCount: Int,
        frequency: String,
        startDate: String,
        visibility: String,
        ville: String
    ) {
        viewModelScope.launch {
            val userName = profile.value?.name ?: "Lesly Zoyem"
            val userPhone = profile.value?.phone ?: "+237 677 88 99 00"
            val cleanPhone = userPhone.replace(" ", "").replace("+", "")
            val firstMember = com.example.data.TontineMember(
                name = userName,
                phone = cleanPhone,
                role = "Créateur",
                hasPaidCurrentTurn = false,
                votes = 0,
                beneficiaryDate = startDate
            )
            val membersSerialized = serializeMembersList(listOf(firstMember))
            
            repository.insertTontine(
                Tontine(
                    name = name,
                    amountPerMember = amountPerMember,
                    currentTurn = 1,
                    membersCount = membersCount,
                    frequency = frequency,
                    startDate = startDate,
                    nextBeneficiary = userName,
                    membersSerialized = membersSerialized,
                    visibility = visibility,
                    ville = ville,
                    userId = cleanPhone
                )
            )
        }
    }

    fun incrementTontineTurn(tontine: Tontine, beneficiaryName: String? = null) {
        viewModelScope.launch {
            if (tontine.currentTurn < tontine.membersCount) {
                val nextTurn = tontine.currentTurn + 1
                val members = tontine.getMembersList().map { member ->
                    member.copy(
                        hasPaidCurrentTurn = false,
                        proofUri = null,
                        isProofValidated = false
                    )
                }
                val nextBeneficiaryName = beneficiaryName ?: calculateBeneficiaryForTurn(members, nextTurn)
                repository.updateTontine(tontine.copy(
                    currentTurn = nextTurn,
                    nextBeneficiary = nextBeneficiaryName,
                    membersSerialized = serializeMembersList(members)
                ))
            }
        }
    }

    fun decrementTontineTurn(tontine: Tontine) {
        viewModelScope.launch {
            if (tontine.currentTurn > 1) {
                val prevTurn = tontine.currentTurn - 1
                val members = tontine.getMembersList()
                val nextBeneficiaryName = calculateBeneficiaryForTurn(members, prevTurn)
                repository.updateTontine(tontine.copy(
                    currentTurn = prevTurn,
                    nextBeneficiary = nextBeneficiaryName
                ))
            }
        }
    }

    fun deleteTontine(tontine: Tontine) {
        viewModelScope.launch {
            repository.deleteTontine(tontine)
        }
    }

    // New actions for Member Management
    fun addMemberToTontine(tontine: Tontine, memberName: String, memberPhone: String, beneficiaryDate: String) {
        viewModelScope.launch {
            val currentMembers = tontine.getMembersList().toMutableList()
            if (currentMembers.any { it.name.lowercase() == memberName.lowercase() }) return@launch
            
            val newMember = com.example.data.TontineMember(
                name = memberName,
                phone = memberPhone.replace(" ", "").replace("+", ""),
                role = "Membre",
                hasPaidCurrentTurn = false,
                votes = 0,
                beneficiaryDate = beneficiaryDate
            )
            currentMembers.add(newMember)
            
            val updatedSerialized = serializeMembersList(currentMembers)
            val nextBeneficiaryName = calculateBeneficiaryForTurn(currentMembers, tontine.currentTurn)
            
            repository.updateTontine(tontine.copy(
                membersSerialized = updatedSerialized,
                nextBeneficiary = nextBeneficiaryName
            ))
        }
    }

    fun uploadBeneficiaryProof(tontine: Tontine, beneficiaryName: String, proofUri: String) {
        viewModelScope.launch {
            val members = tontine.getMembersList().map { member ->
                if (member.name == beneficiaryName) {
                    member.copy(beneficiaryProofUri = proofUri)
                } else {
                    member
                }
            }
            repository.updateTontine(tontine.copy(
                membersSerialized = serializeMembersList(members)
            ))
        }
    }

    fun removeMemberFromTontine(tontine: Tontine, member: com.example.data.TontineMember) {
        viewModelScope.launch {
            val currentMembers = tontine.getMembersList().toMutableList()
            currentMembers.removeAll { it.name == member.name && it.phone == member.phone }
            
            val updatedMembers = recalculateRolesAfterVoteChange(currentMembers)
            val updatedSerialized = serializeMembersList(updatedMembers)
            val nextBeneficiaryName = calculateBeneficiaryForTurn(updatedMembers, tontine.currentTurn)
            
            repository.updateTontine(tontine.copy(
                membersSerialized = updatedSerialized,
                nextBeneficiary = nextBeneficiaryName
            ))
        }
    }

    // Voting Engine
    fun voteForMember(tontine: Tontine, targetMemberName: String) {
        viewModelScope.launch {
            if (tontine.userVotedForName.isNotBlank()) return@launch
            
            val members = tontine.getMembersList().map { member ->
                if (member.name == targetMemberName) {
                    member.copy(votes = member.votes + 1)
                } else {
                    member
                }
            }
            
            val updatedMembers = recalculateRolesAfterVoteChange(members)
            
            repository.updateTontine(tontine.copy(
                userVotedForName = targetMemberName,
                membersSerialized = serializeMembersList(updatedMembers)
            ))
        }
    }

    private fun recalculateRolesAfterVoteChange(members: List<com.example.data.TontineMember>): List<com.example.data.TontineMember> {
        if (members.isEmpty()) return members
        val maxVotesMember = members.filter { it.votes > 0 }.maxByOrNull { it.votes }
        return members.map { member ->
            val isMaxVotes = maxVotesMember != null && member.name == maxVotesMember.name
            val newRole = when {
                member.role == "Créateur" -> "Créateur"
                isMaxVotes -> "Trésorier"
                member.role == "Trésorier" -> "Membre"
                else -> member.role
            }
            member.copy(role = newRole)
        }
    }

    // Dynamic Payment Proofs
    fun uploadMemberPaymentProof(tontine: Tontine, memberName: String, uriString: String) {
        viewModelScope.launch {
            val members = tontine.getMembersList().map { member ->
                if (member.name == memberName) {
                    member.copy(proofUri = uriString, isProofValidated = false)
                } else {
                    member
                }
            }
            repository.updateTontine(tontine.copy(
                membersSerialized = serializeMembersList(members)
            ))
        }
    }

    fun confirmMemberPayment(tontine: Tontine, memberName: String) {
        viewModelScope.launch {
            var members = tontine.getMembersList().map { member ->
                if (member.name == memberName) {
                    member.copy(isProofValidated = true, hasPaidCurrentTurn = true)
                } else {
                    member
                }
            }
            
            val allPaid = members.isNotEmpty() && members.all { it.hasPaidCurrentTurn }
            var nextTurn = tontine.currentTurn
            var nextBeneficiary = tontine.nextBeneficiary
            
            if (allPaid) {
                if (tontine.currentTurn < tontine.membersCount) {
                    nextTurn = tontine.currentTurn + 1
                    members = members.map { member ->
                        member.copy(
                            hasPaidCurrentTurn = false,
                            proofUri = null,
                            isProofValidated = false
                        )
                    }
                    nextBeneficiary = calculateBeneficiaryForTurn(members, nextTurn)
                }
            } else {
                nextBeneficiary = calculateBeneficiaryForTurn(members, nextTurn)
            }
            
            repository.updateTontine(tontine.copy(
                currentTurn = nextTurn,
                nextBeneficiary = nextBeneficiary,
                membersSerialized = serializeMembersList(members)
            ))
        }
    }

    fun rejectMemberPayment(tontine: Tontine, memberName: String) {
        viewModelScope.launch {
            val members = tontine.getMembersList().map { member ->
                if (member.name == memberName) {
                    member.copy(proofUri = null, isProofValidated = false, hasPaidCurrentTurn = false)
                } else {
                    member
                }
            }
            repository.updateTontine(tontine.copy(
                membersSerialized = serializeMembersList(members)
            ))
        }
    }

    fun setTontineBeneficiary(tontine: Tontine, beneficiaryName: String) {
        viewModelScope.launch {
            repository.updateTontine(tontine.copy(
                nextBeneficiary = beneficiaryName
            ))
        }
    }

    // Legacy method definitions for safety and backward-compatibility
    fun voteForTreasurer(tontine: Tontine, candidate: String) {
        viewModelScope.launch {
            if (tontine.userVotedFor.isEmpty()) {
                val updated = when (candidate) {
                    "A" -> tontine.copy(candidateAVotes = tontine.candidateAVotes + 1, userVotedFor = "A")
                    "B" -> tontine.copy(candidateBVotes = tontine.candidateBVotes + 1, userVotedFor = "B")
                    "C" -> tontine.copy(candidateCVotes = tontine.candidateCVotes + 1, userVotedFor = "C")
                    else -> tontine
                }
                repository.updateTontine(updated)
            }
        }
    }

    fun uploadPaymentProof(tontine: Tontine, uri: String) {
        viewModelScope.launch {
            repository.updateTontine(tontine.copy(proofUri = uri, isProofValidated = false))
        }
    }

    fun validatePaymentProof(tontine: Tontine, isValid: Boolean) {
        viewModelScope.launch {
            repository.updateTontine(tontine.copy(isProofValidated = isValid))
        }
    }

    fun resetPaymentProof(tontine: Tontine) {
        viewModelScope.launch {
            repository.updateTontine(tontine.copy(proofUri = null, isProofValidated = false))
        }
    }

    // Profile actions
    fun updateProfile(name: String, phone: String, photoUri: String?, role: String, ville: String, useWhatsAppForReminders: Boolean, isConfigured: Boolean) {
        viewModelScope.launch {
            repository.updateProfile(
                UserProfile(
                    id = 1,
                    name = name,
                    phone = phone,
                    photoUri = photoUri,
                    role = role,
                    ville = ville,
                    useWhatsAppForReminders = useWhatsAppForReminders,
                    isConfigured = isConfigured
                )
            )
        }
    }

    fun loginUser(name: String, phone: String, ville: String = "Douala", useWhatsApp: Boolean = true) {
        viewModelScope.launch {
            val cleanPhone = phone.replace(" ", "").replace("+", "")
            val allTontines = repository.allTontines.firstOrNull() ?: emptyList()
            
            // Infer role if user created any tontine or is a creator/treasurer
            val isCreator = allTontines.any { tontine ->
                (cleanPhone.isNotBlank() && tontine.userId == cleanPhone) ||
                tontine.getMembersList().any { m ->
                    ((cleanPhone.isNotBlank() && m.phone.replace(" ", "").replace("+", "") == cleanPhone) ||
                     m.name.equals(name, ignoreCase = true)) &&
                    (m.role == "Créateur" || m.role == "Trésorier")
                }
            }
            val inferredRole = if (isCreator) "Créateur" else "Membre"

            repository.updateProfile(
                UserProfile(
                    id = 1,
                    name = name,
                    phone = cleanPhone,
                    photoUri = "avatar_1",
                    role = inferredRole,
                    ville = ville,
                    useWhatsAppForReminders = useWhatsApp,
                    isConfigured = true
                )
            )
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.updateProfile(
                UserProfile(
                    id = 1,
                    name = "",
                    phone = "",
                    photoUri = null,
                    role = "Membre",
                    ville = "Douala",
                    useWhatsAppForReminders = true,
                    isConfigured = false
                )
            )
        }
    }

    // Join Request actions
    fun requestToJoinTontine(tontine: Tontine) {
        viewModelScope.launch {
            val userName = profile.value?.name ?: "Utilisateur"
            val userPhone = profile.value?.phone ?: ""
            val currentRequests = tontine.getJoinRequestsList().toMutableList()
            if (currentRequests.any { it.name == userName || it.phone == userPhone }) {
                // Already requested
                return@launch
            }
            currentRequests.add(com.example.data.JoinRequest(
                name = userName,
                phone = userPhone.replace(" ", "").replace("+", ""),
                status = "En attente"
            ))
            val serialized = currentRequests.joinToString("|") {
                "${it.name};${it.phone};${it.status};${it.assignedDate}"
            }
            repository.updateTontine(tontine.copy(joinRequestsSerialized = serialized))
        }
    }

    fun handleJoinRequest(tontine: Tontine, reqName: String, reqPhone: String, accept: Boolean, assignedDate: String) {
        viewModelScope.launch {
            val currentRequests = tontine.getJoinRequestsList().map { req ->
                if (req.name == reqName && req.phone == reqPhone) {
                    req.copy(status = if (accept) "Accepté" else "Refusé", assignedDate = assignedDate)
                } else {
                    req
                }
            }
            val reqSerialized = currentRequests.joinToString("|") {
                "${it.name};${it.phone};${it.status};${it.assignedDate}"
            }
            
            var tontineUpdated = tontine.copy(joinRequestsSerialized = reqSerialized)
            
            if (accept) {
                // Add member to tontine
                val currentMembers = tontine.getMembersList().toMutableList()
                if (!currentMembers.any { it.name.lowercase() == reqName.lowercase() }) {
                    val newMember = com.example.data.TontineMember(
                        name = reqName,
                        phone = reqPhone.replace(" ", "").replace("+", ""),
                        role = "Membre",
                        hasPaidCurrentTurn = false,
                        votes = 0,
                        beneficiaryDate = assignedDate.ifBlank { "2026-07-17" }
                    )
                    currentMembers.add(newMember)
                    val updatedSerialized = serializeMembersList(currentMembers)
                    val nextBeneficiaryName = calculateBeneficiaryForTurn(currentMembers, tontine.currentTurn)
                    tontineUpdated = tontineUpdated.copy(
                        membersSerialized = updatedSerialized,
                        nextBeneficiary = nextBeneficiaryName
                    )
                }
            }
            
            repository.updateTontine(tontineUpdated)
        }
    }

    // ViewModel Factory
    class Factory(private val repository: TontiDetteRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TontiDetteViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return TontiDetteViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
