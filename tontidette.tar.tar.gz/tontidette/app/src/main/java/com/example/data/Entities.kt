package com.example.data

// TODO: Connect to Supabase + Storage. Add role-based access control.

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "debts")
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val amount: Double,
    val isJeDois: Boolean, // true if 'Je dois', false if 'On me doit'
    val date: String,
    val phoneNumber: String,
    val isPaid: Boolean = false,
    val dateRemboursement: String = "",
    val numeroWhatsApp: String = "",
    val estRemboursee: Boolean = false,
    val userId: String = ""
)

@Entity(tableName = "tontines")
data class Tontine(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val amountPerMember: Double,
    val currentTurn: Int = 1,
    val membersCount: Int = 10,
    val frequency: String = "Mensuel", // "Mensuel", "Hebdomadaire"
    val nextBeneficiary: String = "Mamadou Bello",
    val startDate: String = "2026-07-17", // yyyy-MM-dd
    val membersSerialized: String = "",
    val userVotedForName: String = "", // Who the current user voted for
    val visibility: String = "Publique", // "Privée", "Publique"
    val ville: String = "Douala",
    val joinRequestsSerialized: String = "", // format: name;phone;status;assignedDate|...
    
    // Legacy fields to prevent any issues with old queries
    val candidateAName: String = "Elie Kamga",
    val candidateAVotes: Int = 5,
    val candidateBName: String = "Chantal Ngo",
    val candidateBVotes: Int = 3,
    val candidateCName: String = "Rodrigue Talla",
    val candidateCVotes: Int = 4,
    val userVotedFor: String = "",
    val proofUri: String? = null,
    val isProofValidated: Boolean = false,
    val userId: String = ""
) {
    // Member parsing helpers
    fun getMembersList(): List<TontineMember> {
        if (membersSerialized.isBlank()) return emptyList()
        return try {
            membersSerialized.split("|").mapNotNull { memberStr ->
                val parts = memberStr.split(";")
                if (parts.size >= 9) {
                    TontineMember(
                        name = parts[0],
                        phone = parts[1],
                        role = parts[2],
                        hasPaidCurrentTurn = parts[3].toBoolean(),
                        votes = parts[4].toIntOrNull() ?: 0,
                        proofUri = parts[5].takeIf { it != "null" && it.isNotBlank() },
                        isProofValidated = parts[6].toBoolean(),
                        beneficiaryDate = parts[7],
                        beneficiaryProofUri = parts[8].takeIf { it != "null" && it.isNotBlank() }
                    )
                } else if (parts.size >= 7) {
                    TontineMember(
                        name = parts[0],
                        phone = parts[1],
                        role = parts[2],
                        hasPaidCurrentTurn = parts[3].toBoolean(),
                        votes = parts[4].toIntOrNull() ?: 0,
                        proofUri = parts[5].takeIf { it != "null" && it.isNotBlank() },
                        isProofValidated = parts[6].toBoolean(),
                        beneficiaryDate = "",
                        beneficiaryProofUri = null
                    )
                } else if (parts.size >= 4) {
                    TontineMember(
                        name = parts[0],
                        phone = parts[1],
                        role = parts[2],
                        hasPaidCurrentTurn = parts[3].toBoolean(),
                        beneficiaryDate = "",
                        beneficiaryProofUri = null
                    )
                } else null
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getJoinRequestsList(): List<JoinRequest> {
        if (joinRequestsSerialized.isBlank()) return emptyList()
        return try {
            joinRequestsSerialized.split("|").mapNotNull { reqStr ->
                val parts = reqStr.split(";")
                if (parts.size >= 3) {
                    JoinRequest(
                        name = parts[0],
                        phone = parts[1],
                        status = parts[2],
                        assignedDate = if (parts.size >= 4) parts[3] else ""
                    )
                } else null
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

data class TontineMember(
    val name: String,
    val phone: String,
    val role: String, // "Créateur", "Trésorier", "Membre"
    val hasPaidCurrentTurn: Boolean = false,
    val votes: Int = 0,
    val proofUri: String? = null,
    val isProofValidated: Boolean = false,
    val beneficiaryDate: String = "",
    val beneficiaryProofUri: String? = null
)

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1, // Single-row configuration
    val name: String,
    val phone: String,
    val photoUri: String? = null,
    val role: String = "Créateur",
    val ville: String = "Douala",
    val useWhatsAppForReminders: Boolean = true,
    val isConfigured: Boolean = false
)

data class JoinRequest(
    val name: String,
    val phone: String,
    val status: String, // "En attente", "Accepté", "Refusé"
    val assignedDate: String = ""
)
