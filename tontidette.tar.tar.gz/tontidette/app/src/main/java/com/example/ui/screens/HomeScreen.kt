package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Debt
import com.example.data.UserProfile
import com.example.ui.utils.CurrencyUtils

@Composable
fun HomeScreen(
    totalJeDois: Double,
    totalOnMeDoit: Double,
    profile: UserProfile?,
    recentDebts: List<Debt>,
    tontines: List<com.example.data.Tontine>,
    onSelectTab: (Int) -> Unit,
    modifier: Modifier = Modifier,
    onCreateTontineClick: () -> Unit = {}
) {
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    val nextDebt = recentDebts.filter { !it.isPaid }.firstOrNull()
    val nextTontine = tontines.firstOrNull()

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Welcome Banner
            item {
                WelcomeBanner(profile = profile)
            }

            // Debt Overview Metrics
            item {
                OverviewSection(
                    totalJeDois = totalJeDois,
                    totalOnMeDoit = totalOnMeDoit
                )
            }

            // Mon Prochain Tour Card
            item {
                MonProchainTourSection(
                    nextTontine = nextTontine
                )
            }

            // Prochains Rappels Card
            item {
                ProchainsRappelsSection(
                    nextDebt = nextDebt,
                    onSelectTab = onSelectTab
                )
            }

            // Call to action quick shortcuts
            item {
                QuickActionsRow(onSelectTab = onSelectTab)
            }

            // Recent Active Debts section
            item {
                Text(
                    text = "Activités Récentes",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            if (recentDebts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Aucune dette active. Ajoutez-en dans l'onglet Dettes !",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(recentDebts.take(3)) { debt ->
                    RecentDebtRow(debt = debt)
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { onCreateTontineClick() },
            icon = { Icon(Icons.Default.Add, contentDescription = "Créer une Tontine") },
            text = { Text("Créer une Tontine") },
            containerColor = Color(0xFF004D40), // vert foncé
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 16.dp, end = 16.dp)
                .testTag("home_create_tontine_fab")
        )
    }
}

@Composable
fun WelcomeBanner(profile: UserProfile?) {
    val userName = profile?.name ?: "Chargement..."
    val userPhone = profile?.phone ?: "+237 --- -- -- --"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF005A45), // Deep Cameroonian Green
                        Color(0xFF007A5E)  // Forest Green
                    )
                )
            )
            .padding(20.dp)
    ) {
        // Star pattern in background
        Icon(
            imageVector = Icons.Default.Star,
            contentDescription = null,
            tint = Color(0xFFFCD116).copy(alpha = 0.15f), // Golden yellow star of Cameroon
            modifier = Modifier
                .size(120.dp)
                .align(Alignment.CenterEnd)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = Color(0xFFFCD116), // Gold Accent
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.size(24.dp, 14.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFCE1126), // Red Star
                            modifier = Modifier.size(8.dp)
                        )
                    }
                }
                Text(
                    text = "Cameroun",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFFCD116),
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "Bonjour, $userName 👋",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Tél: $userPhone",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Simplifiez la gestion de vos tontines et de vos dettes familiales en toute sécurité.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
fun OverviewSection(
    totalJeDois: Double,
    totalOnMeDoit: Double
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Total que je dois (Red Card)
        Card(
            modifier = Modifier
                .weight(1f)
                .height(130.dp)
                .testTag("total_je_dois_card"),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFFFF2F2) // Soft Red background
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color(0xFFCE1126).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Dette",
                            tint = Color(0xFFCE1126),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "Total que je dois",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF8B0000),
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column {
                    Text(
                        text = CurrencyUtils.formatFCFA(totalJeDois),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFCE1126)
                    )
                    Text(
                        text = "Total à rembourser",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.DarkGray
                    )
                }
            }
        }

        // Total qu'on me doit (Green Card)
        Card(
            modifier = Modifier
                .weight(1f)
                .height(130.dp)
                .testTag("total_on_me_doit_card"),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFE8F8F1) // Soft Green background
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(Color(0xFF007A5E).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowDownward,
                            contentDescription = "Crédit",
                            tint = Color(0xFF007A5E),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "Total qu'on me doit",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF004D3B),
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Column {
                    Text(
                        text = CurrencyUtils.formatFCFA(totalOnMeDoit),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF007A5E)
                    )
                    Text(
                        text = "À récupérer",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionsRow(onSelectTab: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { onSelectTab(1) }, // Switch to Debts
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF007A5E)
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TrendingDown,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Gérer Dettes", style = MaterialTheme.typography.bodyMedium)
            }

            Button(
                onClick = { onSelectTab(2) }, // Switch to Tontines
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFCE1126)
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Voir Tontines", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun RecentDebtRow(debt: Debt) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            if (debt.isJeDois) Color(0xFFCE1126).copy(alpha = 0.1f)
                            else Color(0xFF007A5E).copy(alpha = 0.1f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (debt.isJeDois) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = if (debt.isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Text(
                        text = debt.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (debt.isJeDois) "Je dois • ${debt.date}" else "On me doit • ${debt.date}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            Text(
                text = CurrencyUtils.formatFCFA(debt.amount),
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.ExtraBold,
                color = if (debt.isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E)
            )
        }
    }
}

@Composable
fun MonProchainTourSection(
    nextTontine: com.example.data.Tontine?
) {
    Card(
        modifier = Modifier.fillMaxWidth().testTag("mon_prochain_tour_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color(0xFF007A5E).copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Mon Prochain Tour",
                        tint = Color(0xFF007A5E),
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = "Mon Prochain Tour ⏰",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            if (nextTontine == null) {
                Text(
                    text = "Aucun tour de tontine planifié. Tout est à jour !",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            } else {
                val nextDate = getTurnDateString(nextTontine.startDate, nextTontine.frequency, nextTontine.currentTurn)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = nextTontine.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Bénéficiaire : ${nextTontine.nextBeneficiary}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )
                        Text(
                            text = "Date : $nextDate • Tour ${nextTontine.currentTurn}/${nextTontine.membersCount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF007A5E),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = CurrencyUtils.formatFCFA(nextTontine.amountPerMember),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF007A5E)
                        )
                        Text(
                            text = nextTontine.frequency,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFCE1126),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(Color(0xFFFFF2F2), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProchainsRappelsSection(
    nextDebt: Debt?,
    onSelectTab: (Int) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth().testTag("prochains_rappels_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color(0xFFCE1126).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Rappels",
                            tint = Color(0xFFCE1126),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "Prochains Rappels 🔔",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                
                TextButton(onClick = { onSelectTab(1) }) {
                    Text("Tout voir", color = Color(0xFF007A5E), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            if (nextDebt == null) {
                Text(
                    text = "Aucun rappel de dette en attente. Félicitations !",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = nextDebt.name,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (nextDebt.isJeDois) "Type : Je dois" else "Type : On me doit",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (nextDebt.isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Date limite : ${nextDebt.date}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = CurrencyUtils.formatFCFA(nextDebt.amount),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (nextDebt.isJeDois) Color(0xFFCE1126) else Color(0xFF007A5E)
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Button(
                            onClick = {
                                com.example.ui.screens.sendWhatsAppReminder(context, nextDebt)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "WhatsApp",
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rappeler", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
