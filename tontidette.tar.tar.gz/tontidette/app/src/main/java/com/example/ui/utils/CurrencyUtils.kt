package com.example.ui.utils

import java.text.NumberFormat
import java.util.Locale

object CurrencyUtils {
    /**
     * Formats a double value to FCFA currency string format.
     * Example: 150000.0 becomes "150 000 FCFA"
     */
    fun formatFCFA(amount: Double): String {
        return try {
            val formatter = NumberFormat.getNumberInstance(Locale.FRANCE)
            formatter.maximumFractionDigits = 0
            val formatted = formatter.format(amount)
            "$formatted FCFA"
        } catch (e: Exception) {
            "${amount.toInt()} FCFA"
        }
    }
}
