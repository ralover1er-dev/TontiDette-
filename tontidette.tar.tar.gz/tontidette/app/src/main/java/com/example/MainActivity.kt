package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.TontiDetteDatabase
import com.example.data.TontiDetteRepository
import com.example.ui.TontiDetteViewModel
import com.example.ui.components.NotificationsDialog
import com.example.ui.screens.DebtsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.TontinesScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room Database, Repository and ViewModel Provider
        val database = TontiDetteDatabase.getDatabase(this)
        val repository = TontiDetteRepository(database)
        val factory = TontiDetteViewModel.Factory(repository)
        val viewModel = ViewModelProvider(this, factory)[TontiDetteViewModel::class.java]

        setContent {
            MyApplicationTheme {
                TontiDetteApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TontiDetteApp(viewModel: TontiDetteViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var autoOpenTontineDialog by remember { mutableStateOf(false) }
    var isLoginView by remember { mutableStateOf(true) }
    var showNotificationsDialog by remember { mutableStateOf(false) }

    // Reactive states directly fetched from local Room database via Flow
    val totalJeDois by viewModel.totalJeDois.collectAsStateWithLifecycle()
    val totalOnMeDoit by viewModel.totalOnMeDoit.collectAsStateWithLifecycle()
    val debts by viewModel.debts.collectAsStateWithLifecycle()
    val tontines by viewModel.tontines.collectAsStateWithLifecycle()
    val profile by viewModel.profile.collectAsStateWithLifecycle()

    var reminderDebtToShow by remember { mutableStateOf<com.example.data.Debt?>(null) }
    var hasCheckedReminders by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(debts) {
        if (debts.isNotEmpty() && !hasCheckedReminders) {
            val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
            val todayFriendly = java.text.SimpleDateFormat("dd MMM 2026", java.util.Locale.FRENCH).format(java.util.Date())
            val dueToday = debts.firstOrNull { debt ->
                !debt.isPaid && (debt.dateRemboursement == todayStr || debt.date == todayFriendly)
            }
            if (dueToday != null) {
                reminderDebtToShow = dueToday
            }
            hasCheckedReminders = true
        }
    }

    if (reminderDebtToShow != null) {
        AlertDialog(
            onDismissRequest = { reminderDebtToShow = null },
            title = {
                Text(
                    text = "Rappel de Dette ⏰",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "La dette de ${reminderDebtToShow!!.name} d'un montant de ${com.example.ui.utils.CurrencyUtils.formatFCFA(reminderDebtToShow!!.amount)} est due aujourd'hui !"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val d = reminderDebtToShow!!
                        reminderDebtToShow = null
                        com.example.ui.screens.sendWhatsAppReminder(context, d)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007A5E))
                ) {
                    Text("Rappeler sur WhatsApp", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { reminderDebtToShow = null }) {
                    Text("Fermer")
                }
            }
        )
    }

    if (profile != null && !profile!!.isConfigured) {
        if (isLoginView) {
            LoginScreen(
                onLogin = { name, phone, ville, useWhatsApp ->
                    viewModel.loginUser(name, phone, ville, useWhatsApp)
                    selectedTab = 0
                },
                onNavigateToRegister = {
                    isLoginView = false
                }
            )
        } else {
            OnboardingScreen(
                onCompleteOnboarding = { name, phone, photo, role, ville, useWhatsApp ->
                    viewModel.updateProfile(name, phone, photo, role, ville, useWhatsApp, true)
                    selectedTab = 0
                },
                onNavigateToLogin = {
                    isLoginView = true
                }
            )
        }
        return
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "TontiDette",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        // Precise Cameroonian Flag decorative badge (Green-Red(Star)-Yellow)
                        Row(
                            modifier = Modifier
                                .size(24.dp, 16.dp)
                                .background(Color.Gray)
                        ) {
                            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFF007A5E))) // Green
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(Color(0xFFCE1126)), // Red
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = Color(0xFFFCD116), // Gold Star
                                    modifier = Modifier.size(6.dp)
                                )
                            }
                            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(Color(0xFFFCD116))) // Gold
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF005A45), // Forest Green Theme Top Bar
                    titleContentColor = Color.White
                ),
                actions = {
                    val activeCount = debts.count { !it.isPaid }
                    IconButton(
                        onClick = { showNotificationsDialog = true },
                        modifier = Modifier.testTag("notifications_top_bar_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                if (activeCount > 0) {
                                    Badge(
                                        containerColor = Color(0xFFCE1126),
                                        contentColor = Color.White
                                    ) {
                                        Text("$activeCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Center de notifications",
                                tint = Color.White
                            )
                        }
                    }
                },
                modifier = Modifier.testTag("app_top_bar")
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("app_bottom_nav_bar")
            ) {
                val tabs = listOf(
                    Triple("Accueil", Icons.Default.Home, "tab_home"),
                    Triple("Dettes", Icons.Default.Payments, "tab_debts"),
                    Triple("Tontines", Icons.Default.Groups, "tab_tontines"),
                    Triple("Profil", Icons.Default.Person, "tab_profile")
                )

                tabs.forEachIndexed { index, (label, icon, tag) ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(imageVector = icon, contentDescription = label) },
                        label = {
                            Text(
                                text = label,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color(0xFF007A5E),
                            indicatorColor = Color(0xFF007A5E),
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag(tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> HomeScreen(
                    totalJeDois = totalJeDois,
                    totalOnMeDoit = totalOnMeDoit,
                    profile = profile,
                    recentDebts = debts,
                    tontines = tontines,
                    onSelectTab = { selectedTab = it },
                    onCreateTontineClick = {
                        autoOpenTontineDialog = true
                        selectedTab = 2
                    }
                )
                1 -> DebtsScreen(
                    debts = debts,
                    onAddDebt = { name, amount, isJeDois, date, phone, dateRemb, whatsappNum, paid ->
                        viewModel.addDebt(name, amount, isJeDois, date, phone, dateRemb, whatsappNum, paid)
                    },
                    onTogglePaid = { debt ->
                        viewModel.toggleDebtPayment(debt)
                    },
                    onDeleteDebt = { debt ->
                        viewModel.deleteDebt(debt)
                    }
                )
                2 -> TontinesScreen(
                    tontines = tontines,
                    initShowCreate = autoOpenTontineDialog,
                    onDismissCreate = { autoOpenTontineDialog = false },
                    onAddTontine = { name, amount, turn, members, freq ->
                        viewModel.addTontine(name, amount, turn, members, freq)
                    },
                    onIncrementTurn = { tontine, beneficiary ->
                        viewModel.incrementTontineTurn(tontine, beneficiary)
                    },
                    onDecrementTurn = { tontine ->
                        viewModel.decrementTontineTurn(tontine)
                    },
                    onDeleteTontine = { tontine ->
                        viewModel.deleteTontine(tontine)
                    },
                    onVoteForTreasurer = { tontine, candidate ->
                        viewModel.voteForTreasurer(tontine, candidate)
                    },
                    onUploadProof = { tontine, uri ->
                        viewModel.uploadPaymentProof(tontine, uri)
                    },
                    onValidateProof = { tontine, isValid ->
                        viewModel.validatePaymentProof(tontine, isValid)
                    },
                    onResetProof = { tontine ->
                        viewModel.resetPaymentProof(tontine)
                    },
                    onAddTontineWithDate = { name, amount, members, freq, date ->
                        viewModel.addTontine(name, amount, 1, members, freq, date)
                    },
                    onAddTontineWithDateAndVisibility = { name, amount, members, freq, date, visibility, ville ->
                        viewModel.addTontineWithDateAndVisibility(name, amount, members, freq, date, visibility, ville)
                    },
                    onAddMember = { tontine, name, phone, beneficiaryDate ->
                        viewModel.addMemberToTontine(tontine, name, phone, beneficiaryDate)
                    },
                    onRemoveMember = { tontine, member ->
                        viewModel.removeMemberFromTontine(tontine, member)
                    },
                    onVoteForMember = { tontine, name ->
                        viewModel.voteForMember(tontine, name)
                    },
                    onUploadMemberProof = { tontine, name, uri ->
                        viewModel.uploadMemberPaymentProof(tontine, name, uri)
                    },
                    onUploadBeneficiaryProof = { tontine, name, uri ->
                        viewModel.uploadBeneficiaryProof(tontine, name, uri)
                    },
                    onConfirmMemberPayment = { tontine, name ->
                        viewModel.confirmMemberPayment(tontine, name)
                    },
                    onRejectMemberPayment = { tontine, name ->
                        viewModel.rejectMemberPayment(tontine, name)
                    },
                    onSetBeneficiary = { tontine, name ->
                        viewModel.setTontineBeneficiary(tontine, name)
                    },
                    onJoinRequest = { tontine ->
                        viewModel.requestToJoinTontine(tontine)
                    },
                    onHandleJoinRequest = { tontine, name, phone, accept, date ->
                        viewModel.handleJoinRequest(tontine, name, phone, accept, date)
                    },
                    currentUserName = profile?.name ?: "Lesly Zoyem",
                    currentUserPhone = profile?.phone ?: "",
                    currentUserRole = profile?.role ?: "Créateur",
                    currentUserCity = profile?.ville ?: "Douala"
                )
                3 -> {
                    val cleanPhone = (profile?.phone ?: "").replace(" ", "").replace("+", "")
                    val uName = profile?.name ?: ""
                    val userTontinesCount = tontines.count { tontine ->
                        (cleanPhone.isNotBlank() && tontine.userId == cleanPhone) ||
                        tontine.getMembersList().any { m ->
                            (uName.isNotBlank() && m.name.equals(uName, ignoreCase = true)) ||
                            (cleanPhone.isNotBlank() && m.phone.replace(" ", "").replace("+", "") == cleanPhone)
                        }
                    }
                    ProfileScreen(
                        profile = profile,
                        hasTontines = userTontinesCount > 0,
                        tontinesCount = userTontinesCount,
                        debtsCount = debts.size,
                        totalJeDois = totalJeDois,
                        totalOnMeDoit = totalOnMeDoit,
                        onSaveProfile = { name, phone, photo, role, ville, useWhatsApp ->
                            viewModel.updateProfile(name, phone, photo, role, ville, useWhatsApp, true)
                        },
                        onLogout = {
                            viewModel.logout()
                            selectedTab = 0
                        }
                    )
                }
            }

            if (showNotificationsDialog) {
                NotificationsDialog(
                    debts = debts,
                    tontines = tontines,
                    userProfileName = profile?.name ?: "Utilisateur TontiDette",
                    userPhone = profile?.phone ?: "",
                    onDismiss = { showNotificationsDialog = false },
                    onNavigateToDebts = { selectedTab = 1 },
                    onNavigateToTontines = { selectedTab = 2 }
                )
            }
        }
    }
}
