package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers

class TontiDetteRepository(private val database: TontiDetteDatabase) {
    private val debtDao = database.debtDao()
    private val tontineDao = database.tontineDao()
    private val profileDao = database.userProfileDao()

    val allDebts: Flow<List<Debt>> = debtDao.getAllDebts()
    val allTontines: Flow<List<Tontine>> = tontineDao.getAllTontines()
    val userProfile: Flow<UserProfile?> = profileDao.getProfileFlow()

    suspend fun insertDebt(debt: Debt) = withContext(Dispatchers.IO) {
        debtDao.insertDebt(debt)
    }

    suspend fun updateDebt(debt: Debt) = withContext(Dispatchers.IO) {
        debtDao.updateDebt(debt)
    }

    suspend fun deleteDebt(debt: Debt) = withContext(Dispatchers.IO) {
        debtDao.deleteDebt(debt)
    }

    suspend fun deleteDebtById(id: Int) = withContext(Dispatchers.IO) {
        debtDao.deleteDebtById(id)
    }

    suspend fun insertTontine(tontine: Tontine) = withContext(Dispatchers.IO) {
        tontineDao.insertTontine(tontine)
    }

    suspend fun updateTontine(tontine: Tontine) = withContext(Dispatchers.IO) {
        tontineDao.updateTontine(tontine)
    }

    suspend fun deleteTontine(tontine: Tontine) = withContext(Dispatchers.IO) {
        tontineDao.deleteTontine(tontine)
    }

    suspend fun updateProfile(profile: UserProfile) = withContext(Dispatchers.IO) {
        profileDao.insertProfile(profile)
    }

    suspend fun clearAllUserData() = withContext(Dispatchers.IO) {
        debtDao.deleteAllDebts()
        tontineDao.deleteAllTontines()
    }

    /**
     * Pre-populates the database with Cameroonian-themed dummy data if it is empty.
     * This provides an out-of-the-box working dashboard.
     */
    suspend fun prepopulateIfEmpty() = withContext(Dispatchers.IO) {
        // Check if profile exists
        val currentProfile = profileDao.getProfileDirect()
        if (currentProfile == null) {
            // Default user profile matching Cameroonian context and user's context (unconfigured for onboarding)
            profileDao.insertProfile(
                UserProfile(
                    id = 1,
                    name = "",
                    phone = "",
                    photoUri = null,
                    role = "Membre",
                    ville = "Douala",
                    useWhatsAppForReminders = true,
                    isConfigured = false
                )
            )
        }

        // Check if debts are empty
        val debts = debtDao.getAllDebts().firstOrNull() ?: emptyList()
        if (debts.isEmpty()) {
            // "Je dois" (I owe) - isJeDois = true
            debtDao.insertDebt(
                Debt(
                    name = "Papa Fomekong",
                    amount = 25000.0,
                    isJeDois = true,
                    date = "12 Juil 2026",
                    phoneNumber = "237677123456"
                )
            )
            debtDao.insertDebt(
                Debt(
                    name = "Marlyse (Mfoundi)",
                    amount = 15000.0,
                    isJeDois = true,
                    date = "15 Juil 2026",
                    phoneNumber = "237699876543"
                )
            )

            // "On me doit" (Owed to me) - isJeDois = false
            debtDao.insertDebt(
                Debt(
                    name = "Amadou Taxi",
                    amount = 50000.0,
                    isJeDois = false,
                    date = "05 Juil 2026",
                    phoneNumber = "237655432109"
                )
            )
            debtDao.insertDebt(
                Debt(
                    name = "Docteur Ngassa",
                    amount = 120000.0,
                    isJeDois = false,
                    date = "10 Juil 2026",
                    phoneNumber = "237688112233"
                )
            )
        }

        // Check if tontines are empty
        val tontines = tontineDao.getAllTontines().firstOrNull() ?: emptyList()
        if (tontines.isEmpty()) {
            // //TODO: Connect to Supabase + Supabase Auth + Supabase Storage + RLS. Implement role-based access control.
            tontineDao.insertTontine(
                Tontine(
                    name = "La Concorde de Douala",
                    amountPerMember = 25000.0,
                    currentTurn = 1,
                    membersCount = 8,
                    frequency = "Mensuel",
                    nextBeneficiary = "Chantal Ngo",
                    startDate = "2026-07-10",
                    visibility = "Publique",
                    ville = "Douala",
                    joinRequestsSerialized = "Abel Ngando;237671122334;En attente;2026-08-10|Sidonie Ngo;237651223344;En attente;2026-09-10",
                    membersSerialized = "Papa Fomekong;237677123456;Créateur;true;3;null;false;2026-05-10;null|Elie Kamga;237612345678;Trésorier;true;5;null;false;2026-06-10;null|Chantal Ngo;237698765432;Membre;false;2;null;false;2026-07-10;proof_payment_chantal.png|Rodrigue Talla;237655555555;Membre;false;1;null;false;2026-08-10;null|Mamadou Bello;237611111111;Membre;false;0;null;false;2026-09-10;null|Marlyse Sandjon;237699876543;Membre;false;2;null;false;2026-10-10;null",
                    candidateAName = "Elie Kamga",
                    candidateAVotes = 5,
                    candidateBName = "Chantal Ngo",
                    candidateBVotes = 4,
                    candidateCName = "Rodrigue Talla",
                    candidateCVotes = 3
                )
            )
            tontineDao.insertTontine(
                Tontine(
                    name = "Amicale Wouri",
                    amountPerMember = 50000.0,
                    currentTurn = 2,
                    membersCount = 6,
                    frequency = "Mensuel",
                    nextBeneficiary = "Mamadou Bello",
                    startDate = "2026-06-15",
                    visibility = "Publique",
                    ville = "Douala",
                    joinRequestsSerialized = "",
                    membersSerialized = "Papa Fomekong;237677123456;Créateur;true;4;null;false;2026-05-15;null|Florette Ndoumbe;237699999999;Trésorier;true;11;null;false;2026-06-15;null|Jean-Pierre Nguema;237688888888;Membre;true;8;null;false;2026-07-15;null|Amadou Taxi;237655432109;Membre;false;6;null;false;2026-08-15;null|Mamadou Bello;237611111111;Membre;false;2;null;false;2026-09-15;null",
                    candidateAName = "Jean-Pierre Nguema",
                    candidateAVotes = 8,
                    candidateBName = "Florette Ndoumbe",
                    candidateBVotes = 11,
                    candidateCName = "Amadou Taxi",
                    candidateCVotes = 6
                )
            )
            tontineDao.insertTontine(
                Tontine(
                    name = "Famille Batoufam",
                    amountPerMember = 10000.0,
                    currentTurn = 3,
                    membersCount = 6,
                    frequency = "Hebdomadaire",
                    nextBeneficiary = "Elie Kamga",
                    startDate = "2026-05-10",
                    visibility = "Privée",
                    ville = "Bafoussam",
                    joinRequestsSerialized = "",
                    membersSerialized = "Papa Fomekong;237677123456;Créateur;true;3;null;false;2026-05-10;null|Elie Kamga;237612345678;Trésorier;true;5;null;false;2026-05-17;null|Chantal Ngo;237698765432;Membre;false;2;null;false;2026-05-24;null|Rodrigue Talla;237655555555;Membre;false;1;null;false;2026-05-31;null",
                    candidateAName = "Elie Kamga",
                    candidateAVotes = 5,
                    candidateBName = "Chantal Ngo",
                    candidateBVotes = 4,
                    candidateCName = "Rodrigue Talla",
                    candidateCVotes = 3
                )
            )
        }
    }
}
