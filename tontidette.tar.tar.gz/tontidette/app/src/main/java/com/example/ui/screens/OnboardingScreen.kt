package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    onCompleteOnboarding: (String, String, String?, String, String, Boolean) -> Unit,
    onNavigateToLogin: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var useWhatsApp by remember { mutableStateOf(true) }
    var selectedCity by remember { mutableStateOf("Douala") }
    var avatarOption by remember { mutableStateOf("avatar_1") }
    
    val cities = listOf(
        "Douala", "Yaoundé", "Bafoussam", "Garoua", "Bamenda", 
        "Maroua", "Buea", "Nkongsamba", "Ngaoundéré", "Kribi"
    )
    
    // Quick preset local avatar configurations
    val avatars = listOf("avatar_1", "avatar_2", "avatar_3", "avatar_4")
    
    var dropdownExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF00382B)) // Deep elegant Cameroonian green
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))
            
            // Header / App Branding
            Text(
                text = "TontiDette 🇨🇲",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFFCD116) // Gold color
            )
            
            Text(
                text = "Gérez vos tontines et dettes en toute simplicité. Créez votre compte en quelques secondes.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.padding(horizontal = 8.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Avatar Section
            Text(
                text = "Choisissez votre avatar :",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                avatars.forEach { av ->
                    val isSelected = avatarOption == av
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) Color(0xFFFCD116) else Color.White.copy(alpha = 0.15f)
                            )
                            .clickable { avatarOption = av }
                            .padding(if (isSelected) 3.dp else 0.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(
                                    when (av) {
                                        "avatar_1" -> Color(0xFF007A5E)
                                        "avatar_2" -> Color(0xFFCE1126)
                                        "avatar_3" -> Color(0xFFFCD116)
                                        else -> Color(0xFF1E88E5)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Sélectionné",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Input Form Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("onboarding_card"),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Informations Personnelles",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF005A45)
                    )

                    // Nom complet Input
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nom complet") },
                        placeholder = { Text("Ex: Lesly Zoyem") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_name_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF007A5E),
                            focusedLabelColor = Color(0xFF007A5E)
                        )
                    )

                    val isPhoneValid = phone.length == 12 && phone.startsWith("2376")
                    val phoneError = phone.isNotEmpty() && !isPhoneValid

                    // Numéro de téléphone Input
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }
                            if (digits.length == 9 && !digits.startsWith("237")) {
                                phone = "237$digits"
                            } else {
                                phone = digits
                            }
                        },
                        label = { Text("Numéro de téléphone (2376XXXXXXXX)") },
                        placeholder = { Text("Ex: 237691234567") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_phone_input"),
                        singleLine = true,
                        isError = phoneError,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF007A5E),
                            focusedLabelColor = Color(0xFF007A5E)
                        )
                    )
                    if (phoneError) {
                        Text(
                            text = "Numéro invalide. Ex: 237691234567",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }

                    // WhatsApp Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { useWhatsApp = !useWhatsApp }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Utiliser pour WhatsApp",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Switch(
                            checked = useWhatsApp,
                            onCheckedChange = { useWhatsApp = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF25D366) // WhatsApp green
                            )
                        )
                    }

                    // Ville Dropdown
                    Column {
                        Text(
                            text = "Ville :",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { dropdownExpanded = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("onboarding_city_button"),
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedCity, style = MaterialTheme.typography.bodyLarge)
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.8f)
                            ) {
                                cities.forEach { city ->
                                    DropdownMenuItem(
                                        text = { Text(city) },
                                        onClick = {
                                            selectedCity = city
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val isStartEnabled = name.trim().isNotEmpty() && phone.trim().isNotEmpty() && isPhoneValid

                    // Button Commencer
                    Button(
                        onClick = {
                            if (isStartEnabled) {
                                val cleanPhone = phone.replace(" ", "").replace("+", "")
                                // Default role of onboarding user is "Membre" as per requirement
                                onCompleteOnboarding(
                                    name.trim(),
                                    cleanPhone,
                                    avatarOption,
                                    "Membre",
                                    selectedCity,
                                    useWhatsApp
                                )
                            }
                        },
                        enabled = isStartEnabled,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF007A5E), // Cameroonian Green
                            disabledContainerColor = Color.Gray.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("onboarding_submit_btn")
                    ) {
                        Text(
                            text = "Créer mon compte",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    if (onNavigateToLogin != null) {
                        TextButton(
                            onClick = onNavigateToLogin,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("switch_to_login_btn")
                        ) {
                            Text(
                                text = "Déjà un compte ? Se connecter",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF007A5E)
                            )
                        }
                    }
                }
            }
        }
    }
}
